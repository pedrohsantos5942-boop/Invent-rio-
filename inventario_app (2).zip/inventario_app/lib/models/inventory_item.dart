/// Representa um item adicionado ao inventário.
class InventoryItem {
  final String id;
  final String barcode;
  final int quantity;
  final String location;
  final String? lote;
  final String? validade;
  final DateTime addedAt;

  InventoryItem({
    required this.barcode,
    required this.quantity,
    required this.location,
    this.lote,
    this.validade,
    required this.addedAt,
    String? id,
  }) : id = id ?? '${addedAt.microsecondsSinceEpoch}';

  /// Retorna o horário formatado (HH:mm) para exibição na lista.
  String get formattedTime {
    final hour = addedAt.hour.toString().padLeft(2, '0');
    final minute = addedAt.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }

  /// Retorna a data formatada (dd/MM/yyyy).
  String get formattedDate {
    final day = addedAt.day.toString().padLeft(2, '0');
    final month = addedAt.month.toString().padLeft(2, '0');
    return '$day/$month/${addedAt.year}';
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'barcode': barcode,
        'quantity': quantity,
        'location': location,
        'lote': lote,
        'validade': validade,
        'addedAt': addedAt.toIso8601String(),
      };

  /// Gera uma linha CSV (sem cabeçalho) escapando aspas.
  String toCsvRow() {
    String esc(String? v) => '"${(v ?? '').replaceAll('"', '""')}"';
    return [
      esc(id),
      esc(barcode),
      quantity.toString(),
      esc(location),
      esc(lote),
      esc(validade),
      esc(addedAt.toIso8601String()),
    ].join(',');
  }

  static const csvHeader =
      'id,barcode,quantity,location,lote,validade,addedAt';
}
