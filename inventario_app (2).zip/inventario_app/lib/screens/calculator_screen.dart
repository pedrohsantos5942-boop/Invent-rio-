import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../widgets/stepper_field.dart';

/// Tela de calculadora de quantidade, aberta em sobreposição (modal)
/// a partir da tela de Inventário. Retorna o total calculado via
/// Navigator.pop(context, total) quando o usuário confirma.
class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  // Valores da aba "Por Camadas"
  int _boxesPerLayer = 10;
  int _fullLayers = 8;
  int _partialLayer = 5;
  int _extras = 0;

  int get _total => (_boxesPerLayer * _fullLayers) + _partialLayer + _extras;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _clear() {
    setState(() {
      _boxesPerLayer = 0;
      _fullLayers = 0;
      _partialLayer = 0;
      _extras = 0;
    });
  }

  void _confirm() {
    Navigator.pop(context, _total);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          _buildHeader(context),
          _buildTabBar(),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildByLayersTab(),
                _buildByPalletTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------
  // Header
  // ---------------------------------------------------------------------
  Widget _buildHeader(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 12,
        bottom: 16,
        left: 16,
        right: 8,
      ),
      decoration: const BoxDecoration(
        color: AppColors.primaryBlue,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(18)),
      ),
      child: Row(
        children: [
          const Expanded(
            child: Text(
              'Calculadora de Quantidade',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.close, color: Colors.white),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------
  // Tab bar
  // ---------------------------------------------------------------------
  Widget _buildTabBar() {
    return Container(
      color: AppColors.cardBackground,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: TabBar(
        controller: _tabController,
        labelColor: Colors.white,
        unselectedLabelColor: AppColors.textSecondary,
        indicator: BoxDecoration(
          color: AppColors.primaryBlue,
          borderRadius: BorderRadius.circular(10),
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        dividerColor: Colors.transparent,
        labelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
        tabs: const [
          Tab(text: 'Por Camadas'),
          Tab(text: 'Por Pallet'),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------
  // Aba "Por Camadas"
  // ---------------------------------------------------------------------
  Widget _buildByLayersTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: StepperField(
                  label: 'Caixas por camada',
                  value: _boxesPerLayer,
                  onChanged: (v) => setState(() => _boxesPerLayer = v),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: StepperField(
                  label: 'Camadas completas',
                  value: _fullLayers,
                  onChanged: (v) => setState(() => _fullLayers = v),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: StepperField(
                  label: 'Camada incompleta',
                  value: _partialLayer,
                  onChanged: (v) => setState(() => _partialLayer = v),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: StepperField(
                  label: 'Amarração / Extras',
                  value: _extras,
                  onChanged: (v) => setState(() => _extras = v),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          _buildCalculationCard(),
          const SizedBox(height: 24),
          _buildActionButtons(),
        ],
      ),
    );
  }

  Widget _buildCalculationCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.lightGrey,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: AppColors.primaryBlueLight,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.calculate_outlined,
                color: AppColors.primaryBlue, size: 26),
          ),
          const SizedBox(height: 12),
          Text(
            '($_boxesPerLayer x $_fullLayers) + $_partialLayer + $_extras',
            style: const TextStyle(
              fontSize: 14,
              color: AppColors.textSecondary,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Total $_total unidades',
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    return Row(
      children: [
        Expanded(
          child: OutlinedButton.icon(
            onPressed: _clear,
            icon: const Icon(Icons.refresh, size: 18),
            label: const Text('LIMPAR'),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.textSecondary,
              side: const BorderSide(color: AppColors.border),
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          flex: 2,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              boxShadow: AppColors.buttonShadow(AppColors.primaryGreen),
            ),
            child: ElevatedButton.icon(
              onPressed: _confirm,
              icon: const Icon(Icons.check, size: 20),
              label: Text('USAR QUANTIDADE ($_total)'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryGreen,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 0,
                textStyle: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ---------------------------------------------------------------------
  // Aba "Por Pallet" (placeholder simples, mesma lógica pode ser expandida)
  // ---------------------------------------------------------------------
  Widget _buildByPalletTab() {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          'Cálculo por Pallet em breve.\nUtilize a aba "Por Camadas" por enquanto.',
          textAlign: TextAlign.center,
          style: TextStyle(color: AppColors.textSecondary, fontSize: 14),
        ),
      ),
    );
  }
}
