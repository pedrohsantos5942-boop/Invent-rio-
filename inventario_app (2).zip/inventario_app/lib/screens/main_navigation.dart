import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/navigation_provider.dart';
import '../theme/app_colors.dart';
import 'inventory_screen.dart';
import 'list_screen.dart';
import 'summary_screen.dart';
import 'settings_screen.dart';

/// Shell principal do app: controla a BottomNavigationBar com as
/// 4 abas (Inventário, Lista, Resumo, Configurações). A tela inicial
/// é sempre a de Inventário (index 0). O índice ativo vem do
/// [NavigationProvider], permitindo que outras telas troquem de aba
/// (ex: botão "Ver todos").
class MainNavigation extends StatelessWidget {
  const MainNavigation({super.key});

  static const _screens = [
    InventoryScreen(),
    ListScreen(),
    SummaryScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Consumer<NavigationProvider>(
      builder: (context, nav, _) {
        return Scaffold(
          body: IndexedStack(
            index: nav.currentIndex,
            children: _screens,
          ),
          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              color: AppColors.cardBackground,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.08),
                  blurRadius: 10,
                  offset: const Offset(0, -2),
                ),
              ],
            ),
            child: SafeArea(
              child: BottomNavigationBar(
                currentIndex: nav.currentIndex,
                onTap: nav.setIndex,
                type: BottomNavigationBarType.fixed,
                backgroundColor: AppColors.cardBackground,
                selectedItemColor: AppColors.primaryBlue,
                unselectedItemColor: AppColors.textHint,
                selectedLabelStyle: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
                unselectedLabelStyle: const TextStyle(fontSize: 11),
                elevation: 0,
                items: const [
                  BottomNavigationBarItem(
                    icon: Icon(Icons.qr_code_scanner_outlined),
                    activeIcon: Icon(Icons.qr_code_scanner),
                    label: 'Inventário',
                  ),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.list_alt_outlined),
                    activeIcon: Icon(Icons.list_alt),
                    label: 'Lista',
                  ),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.bar_chart_outlined),
                    activeIcon: Icon(Icons.bar_chart),
                    label: 'Resumo',
                  ),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.settings_outlined),
                    activeIcon: Icon(Icons.settings),
                    label: 'Configurações',
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
