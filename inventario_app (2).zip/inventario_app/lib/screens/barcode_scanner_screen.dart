import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:permission_handler/permission_handler.dart';
import '../theme/app_colors.dart';

/// Tela de leitura de código de barras / QR Code usando a câmera.
///
/// - Se [continuousMode] for `false`, a tela fecha automaticamente (Navigator.pop)
///   assim que o primeiro código válido é lido.
/// - Se [continuousMode] for `true`, a câmera permanece aberta e cada código
///   lido é enviado via [onDetected]; o usuário fecha manualmente pelo X.
///
/// [soundEnabled] controla o feedback sonoro/tátil a cada leitura.
///
/// A tela verifica explicitamente a permissão de câmera antes de iniciar o
/// preview. Se a permissão estiver negada, exibe uma tela de erro com opção
/// de tentar novamente ou abrir as Configurações do sistema — em vez de
/// simplesmente mostrar uma tela em branco (causa mais comum de "a câmera
/// não abre").
class BarcodeScannerScreen extends StatefulWidget {
  final bool continuousMode;
  final bool soundEnabled;
  final ValueChanged<String> onDetected;

  const BarcodeScannerScreen({
    super.key,
    required this.onDetected,
    this.continuousMode = false,
    this.soundEnabled = true,
  });

  @override
  State<BarcodeScannerScreen> createState() => _BarcodeScannerScreenState();
}

enum _PermissionState { checking, granted, denied, permanentlyDenied }

class _BarcodeScannerScreenState extends State<BarcodeScannerScreen>
    with WidgetsBindingObserver {
  MobileScannerController? _controller;

  String? _lastCode;
  DateTime? _lastDetectionTime;
  bool _torchOn = false;

  _PermissionState _permissionState = _PermissionState.checking;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _checkPermission();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _controller?.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Se o usuário voltou das Configurações do sistema após conceder a
    // permissão, revalida automaticamente.
    if (state == AppLifecycleState.resumed &&
        _permissionState != _PermissionState.granted) {
      _checkPermission();
    }
  }

  Future<void> _checkPermission() async {
    setState(() => _permissionState = _PermissionState.checking);

    final status = await Permission.camera.status;

    if (status.isGranted) {
      _initController();
      return;
    }

    // Ainda não foi solicitada ou foi negada uma vez: solicita ao usuário.
    if (status.isDenied) {
      final result = await Permission.camera.request();
      if (result.isGranted) {
        _initController();
        return;
      }
      setState(() {
        _permissionState = result.isPermanentlyDenied
            ? _PermissionState.permanentlyDenied
            : _PermissionState.denied;
      });
      return;
    }

    if (status.isPermanentlyDenied || status.isRestricted) {
      setState(() => _permissionState = _PermissionState.permanentlyDenied);
      return;
    }

    setState(() => _permissionState = _PermissionState.denied);
  }

  void _initController() {
    _controller ??= MobileScannerController(
      detectionSpeed: DetectionSpeed.normal,
    );
    setState(() => _permissionState = _PermissionState.granted);
  }

  void _handleDetection(BarcodeCapture capture) {
    final barcodes = capture.barcodes;
    if (barcodes.isEmpty) return;

    final rawValue = barcodes.first.rawValue;
    if (rawValue == null || rawValue.isEmpty) return;

    // Evita leituras duplicadas do mesmo código em sequência rápida.
    final now = DateTime.now();
    if (_lastCode == rawValue &&
        _lastDetectionTime != null &&
        now.difference(_lastDetectionTime!) < const Duration(seconds: 2)) {
      return;
    }
    _lastCode = rawValue;
    _lastDetectionTime = now;

    _giveFeedback();
    widget.onDetected(rawValue);

    if (widget.continuousMode) {
      // Mantém a câmera aberta; apenas avisa visualmente.
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          duration: const Duration(milliseconds: 900),
          backgroundColor: AppColors.primaryGreen,
          content: Text('Código lido: $rawValue'),
        ),
      );
    } else {
      Navigator.of(context).pop();
    }
  }

  void _giveFeedback() {
    HapticFeedback.mediumImpact();
    if (widget.soundEnabled) {
      SystemSound.play(SystemSoundType.click);
    }
  }

  void _toggleTorch() {
    _controller?.toggleTorch();
    setState(() => _torchOn = !_torchOn);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: switch (_permissionState) {
        _PermissionState.checking => const _CenteredMessage(
            icon: null,
            showSpinner: true,
            title: 'Verificando permissão da câmera...',
          ),
        _PermissionState.denied => _PermissionRequestView(
            onRetry: _checkPermission,
          ),
        _PermissionState.permanentlyDenied => _PermissionSettingsView(
            onOpenSettings: openAppSettings,
            onRetry: _checkPermission,
          ),
        _PermissionState.granted => _buildScannerView(context),
      },
    );
  }

  Widget _buildScannerView(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        MobileScanner(
          controller: _controller,
          onDetect: _handleDetection,
          // Cobre erros que podem ocorrer mesmo após a permissão concedida
          // (ex: câmera em uso por outro app, hardware indisponível).
          errorBuilder: (context, error, child) {
            return _ScannerErrorView(error: error, onRetry: _checkPermission);
          },
        ),
        _buildScanOverlay(),
        _buildTopBar(context),
        if (widget.continuousMode) _buildContinuousFooter(),
      ],
    );
  }

  Widget _buildTopBar(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            IconButton(
              onPressed: () => Navigator.of(context).pop(),
              icon: const Icon(Icons.close, color: Colors.white, size: 28),
            ),
            Text(
              widget.continuousMode
                  ? 'Escaneamento contínuo'
                  : 'Aponte para o código',
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
            ),
            IconButton(
              onPressed: _toggleTorch,
              icon: Icon(
                _torchOn ? Icons.flash_on : Icons.flash_off,
                color: Colors.white,
                size: 26,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildScanOverlay() {
    return Center(
      child: Container(
        width: 260,
        height: 180,
        decoration: BoxDecoration(
          border: Border.all(color: AppColors.primaryGreen, width: 3),
          borderRadius: BorderRadius.circular(16),
        ),
      ),
    );
  }

  Widget _buildContinuousFooter() {
    return Positioned(
      left: 16,
      right: 16,
      bottom: 24,
      child: SafeArea(
        top: false,
        child: ElevatedButton.icon(
          onPressed: () => Navigator.of(context).pop(),
          icon: const Icon(Icons.check),
          label: const Text('CONCLUIR ESCANEAMENTO'),
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primaryGreen,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
          ),
        ),
      ),
    );
  }
}

/// Mensagem central genérica (usada no estado "verificando permissão").
class _CenteredMessage extends StatelessWidget {
  final IconData? icon;
  final String title;
  final bool showSpinner;

  const _CenteredMessage({
    required this.icon,
    required this.title,
    this.showSpinner = false,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (showSpinner)
              const CircularProgressIndicator(color: AppColors.primaryGreen)
            else if (icon != null)
              Icon(icon, size: 56, color: Colors.white70),
            const SizedBox(height: 16),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white, fontSize: 15),
            ),
          ],
        ),
      ),
    );
  }
}

/// Exibida quando a permissão foi negada (mas ainda pode ser solicitada
/// novamente pelo próprio app).
class _PermissionRequestView extends StatelessWidget {
  final VoidCallback onRetry;

  const _PermissionRequestView({required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.camera_alt_outlined, size: 56, color: Colors.white70),
            const SizedBox(height: 16),
            const Text(
              'Precisamos da sua permissão para usar a câmera e ler o código de barras.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white, fontSize: 15),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: onRetry,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryBlue,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text('Permitir acesso à câmera'),
            ),
            const SizedBox(height: 12),
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancelar', style: TextStyle(color: Colors.white70)),
            ),
          ],
        ),
      ),
    );
  }
}

/// Exibida quando a permissão foi negada permanentemente ("Não perguntar
/// novamente"). Nesse caso o app não pode mais solicitar — é preciso ir
/// até as Configurações do sistema.
class _PermissionSettingsView extends StatelessWidget {
  final VoidCallback onOpenSettings;
  final VoidCallback onRetry;

  const _PermissionSettingsView({required this.onOpenSettings, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.no_photography_outlined, size: 56, color: Colors.white70),
            const SizedBox(height: 16),
            const Text(
              'O acesso à câmera foi bloqueado permanentemente para este app.\n'
              'Ative manualmente em Configurações > Apps > Inventário > Permissões.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white, fontSize: 15),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: onOpenSettings,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryBlue,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text('Abrir Configurações'),
            ),
            const SizedBox(height: 12),
            TextButton(
              onPressed: onRetry,
              child: const Text('Já ativei, tentar novamente',
                  style: TextStyle(color: Colors.white70)),
            ),
          ],
        ),
      ),
    );
  }
}

/// Exibida quando o preview da câmera falha mesmo com permissão concedida
/// (hardware ocupado, indisponível, etc.).
class _ScannerErrorView extends StatelessWidget {
  final MobileScannerException error;
  final VoidCallback onRetry;

  const _ScannerErrorView({required this.error, required this.onRetry});

  String get _friendlyMessage {
    switch (error.errorCode) {
      case MobileScannerErrorCode.permissionDenied:
        return 'Permissão de câmera negada pelo sistema.';
      case MobileScannerErrorCode.unsupported:
        return 'Este dispositivo não tem suporte a leitura de câmera.\n'
            '(Emuladores e simuladores muitas vezes não simulam câmera real.)';
      default:
        return 'Não foi possível abrir a câmera.\nDetalhe: ${error.errorCode}';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 56, color: Colors.orangeAccent),
            const SizedBox(height: 16),
            Text(
              _friendlyMessage,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white, fontSize: 15),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: onRetry,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryBlue,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text('Tentar novamente'),
            ),
          ],
        ),
      ),
    );
  }
}
