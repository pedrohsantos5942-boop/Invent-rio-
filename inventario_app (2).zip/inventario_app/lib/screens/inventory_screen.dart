import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/inventory_item.dart';
import '../providers/inventory_provider.dart';
import '../providers/navigation_provider.dart';
import '../theme/app_colors.dart';
import '../widgets/stepper_field.dart';
import 'barcode_scanner_screen.dart';
import 'calculator_screen.dart';

/// Tela principal de Inventário: escaneamento de código de barras,
/// preenchimento de posição/lote/validade/quantidade e listagem dos
/// últimos 3 itens adicionados (dados reais via [InventoryProvider]).
class InventoryScreen extends StatefulWidget {
  const InventoryScreen({super.key});

  @override
  State<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends State<InventoryScreen> {
  final TextEditingController _barcodeController = TextEditingController();
  final TextEditingController _locationController = TextEditingController();
  final TextEditingController _loteController = TextEditingController();
  final TextEditingController _validadeController = TextEditingController();
  final TextEditingController _filterController = TextEditingController();

  int _quantity = 0;
  String? _registroDeLote;

  static const _registroOptions = ['Nenhum', 'Lote A', 'Lote B', 'Novo Registro'];

  @override
  void dispose() {
    _barcodeController.dispose();
    _locationController.dispose();
    _loteController.dispose();
    _validadeController.dispose();
    _filterController.dispose();
    super.dispose();
  }

  // ---------------------------------------------------------------------
  // Ações
  // ---------------------------------------------------------------------

  Future<void> _openScanner() async {
    final provider = context.read<InventoryProvider>();
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => BarcodeScannerScreen(
          continuousMode: provider.continuousScanMode,
          soundEnabled: provider.soundOnScan,
          onDetected: (code) {
            setState(() => _barcodeController.text = code);
          },
        ),
      ),
    );
  }

  Future<void> _openCalculator() async {
    final result = await Navigator.push<int>(
      context,
      MaterialPageRoute(builder: (_) => const CalculatorScreen()),
    );
    if (result != null) {
      setState(() => _quantity = result);
    }
  }

  void _confirmPosition() {
    if (_locationController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Informe a posição antes de confirmar.')),
      );
      return;
    }
    FocusScope.of(context).unfocus();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: AppColors.primaryGreen,
        content: Text('Posição "${_locationController.text.trim()}" confirmada.'),
      ),
    );
  }

  void _addItem() {
    if (_barcodeController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Escaneie ou informe um código antes de adicionar.')),
      );
      return;
    }

    final newItem = InventoryItem(
      barcode: _barcodeController.text.trim(),
      quantity: _quantity,
      location: _locationController.text.trim().isEmpty
          ? '-'
          : _locationController.text.trim(),
      lote: _loteController.text.trim().isEmpty ? null : _loteController.text.trim(),
      validade:
          _validadeController.text.trim().isEmpty ? null : _validadeController.text.trim(),
      addedAt: DateTime.now(),
    );

    context.read<InventoryProvider>().addItem(newItem);

    setState(() {
      _barcodeController.clear();
      _locationController.clear();
      _loteController.clear();
      _validadeController.clear();
      _registroDeLote = null;
      _quantity = 0;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        backgroundColor: AppColors.primaryGreen,
        content: Text('Item adicionado com sucesso!'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          _buildHeader(context),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _buildUserCard(),
                  const SizedBox(height: 16),
                  _buildScanButton(),
                  const SizedBox(height: 20),
                  _buildBarcodeField(),
                  const SizedBox(height: 14),
                  _buildLoteValidadeRow(),
                  const SizedBox(height: 14),
                  _buildLocationRow(),
                  const SizedBox(height: 14),
                  _buildQuantityRow(),
                  const SizedBox(height: 14),
                  _buildRegistroLoteDropdown(),
                  const SizedBox(height: 20),
                  _buildAddButton(),
                  const SizedBox(height: 28),
                  _buildRecentHeader(),
                  const SizedBox(height: 12),
                  _buildFilterField(),
                  const SizedBox(height: 12),
                  _buildRecentList(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------
  // Header
  // ---------------------------------------------------------------------
  Widget _buildHeader(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 12,
        bottom: 16,
        left: 8,
        right: 8,
      ),
      decoration: const BoxDecoration(
        color: AppColors.primaryBlue,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(18)),
      ),
      child: Row(
        children: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.menu, color: Colors.white),
          ),
          const Expanded(
            child: Text(
              'Gestão de Inventário',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.cloud_outlined, color: Colors.white),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------
  // Card do usuário
  // ---------------------------------------------------------------------
  Widget _buildUserCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(14),
        boxShadow: AppColors.softShadow,
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 22,
            backgroundColor: AppColors.primaryBlueLight,
            child: const Icon(Icons.person, color: AppColors.primaryBlue),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text(
                  'Inventariante',
                  style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
                ),
                SizedBox(height: 2),
                Text(
                  'Pedro Henrique',
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
              ],
            ),
          ),
          TextButton(
            onPressed: () {},
            child: const Text(
              'Alterar',
              style: TextStyle(
                color: AppColors.primaryBlue,
                fontWeight: FontWeight.w700,
                fontSize: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------
  // Botão de escanear
  // ---------------------------------------------------------------------
  Widget _buildScanButton() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        boxShadow: AppColors.buttonShadow(AppColors.primaryBlue),
      ),
      child: ElevatedButton.icon(
        onPressed: _openScanner,
        icon: const Icon(Icons.qr_code_scanner, size: 22),
        label: const Text('ESCANEAR CÓDIGO DE BARRAS'),
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primaryBlue,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 18),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          elevation: 0,
          textStyle: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.3,
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------
  // Campos de input
  // ---------------------------------------------------------------------
  Widget _buildBarcodeField() {
    return _LabeledField(
      label: 'Código escaneado',
      child: TextField(
        controller: _barcodeController,
        decoration: InputDecoration(
          hintText: 'Aguardando leitura...',
          hintStyle: const TextStyle(color: AppColors.textHint, fontSize: 14),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          suffixIcon: IconButton(
            icon: const Icon(Icons.copy_outlined, color: AppColors.primaryBlue, size: 20),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Código copiado.')),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildLoteValidadeRow() {
    return Row(
      children: [
        Expanded(
          child: _LabeledField(
            label: 'Lote',
            child: TextField(
              controller: _loteController,
              decoration: const InputDecoration(
                hintText: 'Opcional',
                hintStyle: TextStyle(color: AppColors.textHint, fontSize: 14),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 14),
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _LabeledField(
            label: 'Validade',
            child: TextField(
              controller: _validadeController,
              decoration: const InputDecoration(
                hintText: 'Opcional',
                hintStyle: TextStyle(color: AppColors.textHint, fontSize: 14),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 14),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLocationRow() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Posição / Location',
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: AppColors.textSecondary,
          ),
        ),
        const SizedBox(height: 6),
        Row(
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: AppColors.cardBackground,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppColors.border),
                ),
                child: TextField(
                  controller: _locationController,
                  decoration: const InputDecoration(
                    hintText: 'Ex: H105',
                    hintStyle: TextStyle(color: AppColors.textHint, fontSize: 14),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                    suffixIcon: Icon(Icons.location_on_outlined,
                        color: AppColors.primaryBlue, size: 20),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
            OutlinedButton(
              onPressed: _confirmPosition,
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.primaryBlue,
                side: const BorderSide(color: AppColors.primaryBlue),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: const Text(
                'Confirmar Posição',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildQuantityRow() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Quantidade',
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: AppColors.textSecondary,
          ),
        ),
        const SizedBox(height: 6),
        Row(
          children: [
            Expanded(
              flex: 3,
              child: StepperField(
                value: _quantity,
                onChanged: (v) => setState(() => _quantity = v),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              flex: 2,
              child: OutlinedButton.icon(
                onPressed: _openCalculator,
                icon: const Icon(Icons.calculate_outlined, size: 18),
                label: const Text('Calculadora'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.primaryBlue,
                  backgroundColor: AppColors.primaryBlueLight,
                  side: const BorderSide(color: AppColors.primaryBlueLight),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildRegistroLoteDropdown() {
    return _LabeledField(
      label: 'Registro de Lote',
      child: DropdownButtonHideUnderline(
        child: DropdownButtonFormField<String>(
          value: _registroDeLote,
          isExpanded: true,
          icon: const Icon(Icons.keyboard_arrow_down, color: AppColors.textSecondary),
          decoration: const InputDecoration(
            border: InputBorder.none,
            contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          ),
          hint: const Text(
            'Registro de Lote (opcional)',
            style: TextStyle(color: AppColors.textHint, fontSize: 14),
          ),
          items: _registroOptions
              .map((opt) => DropdownMenuItem(value: opt, child: Text(opt)))
              .toList(),
          onChanged: (value) => setState(() => _registroDeLote = value),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------
  // Botão adicionar
  // ---------------------------------------------------------------------
  Widget _buildAddButton() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        boxShadow: AppColors.buttonShadow(AppColors.primaryGreen),
      ),
      child: ElevatedButton.icon(
        onPressed: _addItem,
        icon: const Icon(Icons.check_circle_outline, size: 22),
        label: const Text('ADICIONAR ITEM'),
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primaryGreen,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 18),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          elevation: 0,
          textStyle: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.3,
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------
  // Lista de itens recentes (dados reais do Provider)
  // ---------------------------------------------------------------------
  Widget _buildRecentHeader() {
    return Row(
      children: [
        const Expanded(
          child: Text(
            'Últimos itens adicionados',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
        ),
        TextButton(
          onPressed: () => context.read<NavigationProvider>().setIndex(1),
          child: const Text(
            'Ver todos',
            style: TextStyle(
              color: AppColors.primaryBlue,
              fontWeight: FontWeight.w600,
              fontSize: 13,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildFilterField() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.border),
      ),
      child: TextField(
        controller: _filterController,
        onChanged: (_) => setState(() {}),
        decoration: const InputDecoration(
          hintText: 'Filtrar por localização, ou data do...',
          hintStyle: TextStyle(color: AppColors.textHint, fontSize: 13),
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          prefixIcon: Icon(Icons.search, color: AppColors.textHint, size: 20),
        ),
      ),
    );
  }

  Widget _buildRecentList() {
    return Consumer<InventoryProvider>(
      builder: (context, provider, _) {
        final query = _filterController.text.trim().toLowerCase();
        var items = provider.recentItems;
        if (query.isNotEmpty) {
          items = items
              .where((e) =>
                  e.barcode.toLowerCase().contains(query) ||
                  e.location.toLowerCase().contains(query))
              .toList();
        }

        if (items.isEmpty) {
          return const Padding(
            padding: EdgeInsets.symmetric(vertical: 24),
            child: Center(
              child: Text(
                'Nenhum item adicionado ainda.',
                style: TextStyle(color: AppColors.textSecondary),
              ),
            ),
          );
        }

        return ListView.separated(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: items.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (context, index) => _RecentItemTile(item: items[index]),
        );
      },
    );
  }

}

/// Card de input padrão com rótulo acima do campo.
class _LabeledField extends StatelessWidget {
  final String label;
  final Widget child;

  const _LabeledField({required this.label, required this.child});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: AppColors.textSecondary,
          ),
        ),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(
            color: AppColors.cardBackground,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.border),
          ),
          child: child,
        ),
      ],
    );
  }
}

/// Item da lista de "Últimos itens adicionados".
class _RecentItemTile extends StatelessWidget {
  final InventoryItem item;

  const _RecentItemTile({required this.item});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(12),
        boxShadow: AppColors.softShadow,
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: AppColors.primaryBlueLight,
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.inventory_2_outlined,
                color: AppColors.primaryBlue, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.barcode,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  item.location,
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '${item.quantity} un.',
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                item.formattedTime,
                style: const TextStyle(
                  fontSize: 11,
                  color: AppColors.textHint,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
