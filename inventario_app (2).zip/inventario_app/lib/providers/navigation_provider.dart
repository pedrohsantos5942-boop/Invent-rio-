import 'package:flutter/foundation.dart';

/// Controla a aba atualmente selecionada na BottomNavigationBar,
/// permitindo que outras telas (ex: botão "Ver todos") troquem de aba
/// programaticamente.
class NavigationProvider extends ChangeNotifier {
  int _currentIndex = 0;

  int get currentIndex => _currentIndex;

  void setIndex(int index) {
    if (_currentIndex == index) return;
    _currentIndex = index;
    notifyListeners();
  }
}
