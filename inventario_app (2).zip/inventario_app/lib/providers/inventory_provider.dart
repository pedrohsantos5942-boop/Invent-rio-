import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../models/inventory_item.dart';

/// Gerenciador de estado global do app: mantém a lista real de itens
/// inventariados e as preferências de escaneamento, expostos a toda a
/// árvore de widgets via Provider (ChangeNotifierProvider em main.dart).
class InventoryProvider extends ChangeNotifier {
  final List<InventoryItem> _items = [];

  // ---------------------------------------------------------------------
  // Configurações (Tela de Configurações)
  // ---------------------------------------------------------------------
  bool _continuousScanMode = false;
  bool _soundOnScan = true;

  bool get continuousScanMode => _continuousScanMode;
  bool get soundOnScan => _soundOnScan;

  void setContinuousScanMode(bool value) {
    _continuousScanMode = value;
    notifyListeners();
  }

  void setSoundOnScan(bool value) {
    _soundOnScan = value;
    notifyListeners();
  }

  // ---------------------------------------------------------------------
  // Itens de inventário
  // ---------------------------------------------------------------------

  /// Lista completa (mais recente primeiro), somente leitura.
  List<InventoryItem> get items => List.unmodifiable(_items);

  /// Últimos 3 itens adicionados, usados na tela principal.
  List<InventoryItem> get recentItems => _items.take(3).toList();

  int get totalRecords => _items.length;

  /// Soma de todas as quantidades registradas (total de itens contados).
  int get totalUnitsCounted =>
      _items.fold<int>(0, (sum, item) => sum + item.quantity);

  /// Quantidade de localizações distintas já visitadas.
  int get uniqueLocationsCount => _items
      .map((e) => e.location.trim().toLowerCase())
      .where((l) => l.isNotEmpty && l != '-')
      .toSet()
      .length;

  void addItem(InventoryItem item) {
    _items.insert(0, item);
    notifyListeners();
  }

  void removeItem(String id) {
    _items.removeWhere((e) => e.id == id);
    notifyListeners();
  }

  void clearAll() {
    _items.clear();
    notifyListeners();
  }

  /// Filtra itens por código de barras ou localização (case-insensitive).
  List<InventoryItem> search(String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return items;
    return _items
        .where((e) =>
            e.barcode.toLowerCase().contains(q) ||
            e.location.toLowerCase().contains(q))
        .toList();
  }

  // ---------------------------------------------------------------------
  // Exportação
  // ---------------------------------------------------------------------

  String exportAsJson() {
    return const JsonEncoder.withIndent('  ')
        .convert(_items.map((e) => e.toJson()).toList());
  }

  String exportAsCsv() {
    final buffer = StringBuffer()..writeln(InventoryItem.csvHeader);
    for (final item in _items) {
      buffer.writeln(item.toCsvRow());
    }
    return buffer.toString();
  }
}
