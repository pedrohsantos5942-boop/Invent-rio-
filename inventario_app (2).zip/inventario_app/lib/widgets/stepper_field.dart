import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

/// Campo numérico com botões de incremento/decremento como quadrados
/// separados à direita do valor, igual ao layout de referência.
class StepperField extends StatelessWidget {
  final String? label;
  final int value;
  final ValueChanged<int> onChanged;
  final int min;
  final int step;

  const StepperField({
    super.key,
    this.label,
    required this.value,
    required this.onChanged,
    this.min = 0,
    this.step = 1,
  });

  void _decrement() {
    final next = value - step;
    onChanged(next < min ? min : next);
  }

  void _increment() => onChanged(value + step);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (label != null) ...[
          Text(
            label!,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: AppColors.textSecondary,
            ),
          ),
          const SizedBox(height: 6),
        ],
        Row(
          children: [
            _SquareButton(icon: Icons.remove, onTap: _decrement),
            const SizedBox(width: 8),
            Expanded(
              child: Container(
                height: 48,
                alignment: Alignment.centerLeft,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: AppColors.cardBackground,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppColors.border),
                ),
                child: Text(
                  '$value',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            _SquareButton(icon: Icons.add, onTap: _increment),
          ],
        ),
      ],
    );
  }
}

class _SquareButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _SquareButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        width: 48,
        height: 48,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: AppColors.lightGrey,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, size: 20, color: AppColors.textPrimary),
      ),
    );
  }
}
