import 'package:flutter/material.dart';

/// Paleta de cores centralizada do app, seguindo o esquema
/// azul (ações principais / navegação) e verde (confirmação / sucesso).
class AppColors {
  AppColors._();

  static const Color primaryBlue = Color(0xFF2D6CDF);
  static const Color primaryBlueDark = Color(0xFF1F53B5);
  static const Color primaryBlueLight = Color(0xFFEAF1FD);

  static const Color primaryGreen = Color(0xFF34A853);
  static const Color primaryGreenDark = Color(0xFF2A8A44);

  static const Color background = Color(0xFFF5F7FA);
  static const Color cardBackground = Color(0xFFFFFFFF);
  static const Color lightGrey = Color(0xFFF0F2F5);

  static const Color textPrimary = Color(0xFF1A1F36);
  static const Color textSecondary = Color(0xFF6B7280);
  static const Color textHint = Color(0xFF9CA3AF);

  static const Color border = Color(0xFFE3E7ED);

  static List<BoxShadow> softShadow = [
    BoxShadow(
      color: Colors.black.withOpacity(0.06),
      blurRadius: 12,
      offset: const Offset(0, 4),
    ),
  ];

  static List<BoxShadow> buttonShadow(Color color) => [
        BoxShadow(
          color: color.withOpacity(0.35),
          blurRadius: 10,
          offset: const Offset(0, 4),
        ),
      ];
}
