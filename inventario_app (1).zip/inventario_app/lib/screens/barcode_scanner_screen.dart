import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import '../theme/app_colors.dart';

/// Tela de leitura de código de barras / QR Code usando a câmera.
///
/// - Se [continuousMode] for `false`, a tela fecha automaticamente (Navigator.pop)
///   assim que o primeiro código válido é lido.
/// - Se [continuousMode] for `true`, a câmera permanece aberta e cada código
///   lido é enviado via [onDetected]; o usuário fecha manualmente pelo X.
///
/// [soundEnabled] controla o feedback sonoro/tátil a cada leitura.
class BarcodeScannerScreen extends StatefulWidget {
  final bool continuousMode;
  final bool soundEnabled;
  final ValueChanged<String> onDetected;

  const BarcodeScannerScreen({
    super.key,
    required this.onDetected,
    this.continuousMode = false,
    this.soundEnabled = true,
  });

  @override
  State<BarcodeScannerScreen> createState() => _BarcodeScannerScreenState();
}

class _BarcodeScannerScreenState extends State<BarcodeScannerScreen> {
  final MobileScannerController _controller = MobileScannerController(
    detectionSpeed: DetectionSpeed.normal,
  );

  String? _lastCode;
  DateTime? _lastDetectionTime;
  bool _torchOn = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _handleDetection(BarcodeCapture capture) {
    final barcodes = capture.barcodes;
    if (barcodes.isEmpty) return;

    final rawValue = barcodes.first.rawValue;
    if (rawValue == null || rawValue.isEmpty) return;

    // Evita leituras duplicadas do mesmo código em sequência rápida.
    final now = DateTime.now();
    if (_lastCode == rawValue &&
        _lastDetectionTime != null &&
        now.difference(_lastDetectionTime!) < const Duration(seconds: 2)) {
      return;
    }
    _lastCode = rawValue;
    _lastDetectionTime = now;

    _giveFeedback();
    widget.onDetected(rawValue);

    if (widget.continuousMode) {
      // Mantém a câmera aberta; apenas avisa visualmente.
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          duration: const Duration(milliseconds: 900),
          backgroundColor: AppColors.primaryGreen,
          content: Text('Código lido: $rawValue'),
        ),
      );
    } else {
      Navigator.of(context).pop();
    }
  }

  void _giveFeedback() {
    // Feedback tátil sempre ativo (leve), som apenas se habilitado.
    HapticFeedback.mediumImpact();
    if (widget.soundEnabled) {
      SystemSound.play(SystemSoundType.click);
    }
  }

  void _toggleTorch() {
    _controller.toggleTorch();
    setState(() => _torchOn = !_torchOn);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          MobileScanner(
            controller: _controller,
            onDetect: _handleDetection,
          ),
          _buildScanOverlay(),
          _buildTopBar(context),
          if (widget.continuousMode) _buildContinuousFooter(),
        ],
      ),
    );
  }

  Widget _buildTopBar(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            IconButton(
              onPressed: () => Navigator.of(context).pop(),
              icon: const Icon(Icons.close, color: Colors.white, size: 28),
            ),
            Text(
              widget.continuousMode
                  ? 'Escaneamento contínuo'
                  : 'Aponte para o código',
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
            ),
            IconButton(
              onPressed: _toggleTorch,
              icon: Icon(
                _torchOn ? Icons.flash_on : Icons.flash_off,
                color: Colors.white,
                size: 26,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildScanOverlay() {
    return Center(
      child: Container(
        width: 260,
        height: 180,
        decoration: BoxDecoration(
          border: Border.all(color: AppColors.primaryGreen, width: 3),
          borderRadius: BorderRadius.circular(16),
        ),
      ),
    );
  }

  Widget _buildContinuousFooter() {
    return Positioned(
      left: 16,
      right: 16,
      bottom: 24,
      child: SafeArea(
        top: false,
        child: ElevatedButton.icon(
          onPressed: () => Navigator.of(context).pop(),
          icon: const Icon(Icons.check),
          label: const Text('CONCLUIR ESCANEAMENTO'),
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primaryGreen,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
          ),
        ),
      ),
    );
  }
}
