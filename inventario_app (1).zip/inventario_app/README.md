# Inventário de Estoque — App Flutter (funcional)

App mobile completo de inventário de estoque: leitura real de código de
barras/QR Code pela câmera, estado global com Provider, lista pesquisável
com exclusão, dashboard de resumo e configurações (escaneamento contínuo,
som, exportação e limpeza de dados).

## Estrutura do projeto

```
lib/
├── main.dart                        # Entrada do app, MultiProvider, tema
├── theme/
│   └── app_colors.dart              # Paleta de cores centralizada
├── models/
│   └── inventory_item.dart          # Modelo do item (com toJson/toCsvRow)
├── providers/
│   ├── inventory_provider.dart      # Estado global: itens, configs, exportação
│   └── navigation_provider.dart     # Controla a aba ativa da bottom nav
├── widgets/
│   └── stepper_field.dart           # Campo numérico com botões +/- separados
└── screens/
    ├── main_navigation.dart         # Shell com BottomNavigationBar (4 abas)
    ├── inventory_screen.dart        # Tela principal: Inventário
    ├── barcode_scanner_screen.dart  # Câmera de leitura (mobile_scanner)
    ├── calculator_screen.dart       # Calculadora de quantidade (overlay)
    ├── list_screen.dart             # Lista completa, busca e exclusão
    ├── summary_screen.dart          # Dashboard / Resumo
    └── settings_screen.dart         # Configurações
```

## Como rodar

1. Certifique-se de ter o Flutter SDK instalado (`flutter --version`).
2. Dentro da pasta do projeto, instale as dependências:
   ```bash
   flutter pub get
   ```
3. Configure as permissões nativas de câmera (obrigatório — veja abaixo).
4. Rode o app em um emulador ou dispositivo físico conectado:
   ```bash
   flutter run
   ```

> ⚠️ A leitura de código de barras usa a câmera real do dispositivo. Em
> emuladores Android sem câmera configurada, o preview pode não funcionar;
> teste preferencialmente em um dispositivo físico.

## ⚙️ Configuração obrigatória: permissões de câmera

O pacote `mobile_scanner` precisa que a permissão de câmera seja declarada
nos projetos nativos gerados pelo `flutter create`.

### Android — `android/app/src/main/AndroidManifest.xml`

Adicione dentro da tag `<manifest>`, antes da tag `<application>`:

```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-feature android:name="android.hardware.camera" android:required="false" />
```

Verifique também em `android/app/build.gradle` que `minSdkVersion` seja
**21 ou superior** (exigido pelo `mobile_scanner`):

```gradle
defaultConfig {
    minSdkVersion 21
    ...
}
```

### iOS — `ios/Runner/Info.plist`

Adicione dentro da tag `<dict>` principal:

```xml
<key>NSCameraUsageDescription</key>
<string>Precisamos da câmera para escanear códigos de barras dos itens do estoque.</string>
```

Sem essa chave, o app trava/fecha ao tentar abrir a câmera no iOS.

## Dependências (`pubspec.yaml`)

| Pacote | Uso |
|---|---|
| `provider` | Estado global (itens do inventário, configurações, aba ativa) |
| `mobile_scanner` | Leitura de código de barras/QR Code via câmera |
| `share_plus` | Compartilhar/exportar o arquivo CSV ou JSON gerado |
| `path_provider` | Local temporário para salvar o arquivo antes de compartilhar |

## Funcionalidades implementadas

### 1. Leitor de código de barras funcional
- Botão "ESCANEAR CÓDIGO DE BARRAS" abre a câmera (`BarcodeScannerScreen`).
- Ao detectar um código, o campo "Código escaneado" é preenchido
  automaticamente.
- Feedback tátil (vibração) sempre ativo e som de confirmação
  (`SystemSound.play`) controlado pela configuração "Som ao escanear".
- Suporta **modo de escaneamento contínuo**: se ativado nas Configurações,
  a câmera permanece aberta para ler vários códigos em sequência; se
  desativado, fecha automaticamente após a primeira leitura.

### 2. Estado global (Provider)
- `InventoryProvider` (ChangeNotifier) mantém a lista real de itens,
  as configurações de escaneamento e os métodos de busca/exportação.
- Ao clicar em "ADICIONAR ITEM", um `InventoryItem` completo (código,
  localização, lote, validade, quantidade e horário) é salvo na lista.
- A seção "Últimos itens adicionados" na tela principal é reativa
  (`Consumer<InventoryProvider>`) e sempre mostra os 3 itens mais recentes.

### 3. Tela de Lista funcional
- Exibe todos os itens salvos, com contador no cabeçalho.
- Campo de busca filtra por código de barras ou localização em tempo real.
- Exclusão por **arrastar para o lado** (`Dismissible`, com diálogo de
  confirmação) ou pelo **ícone de lixeira** em cada item.

### 4. Tela de Configurações funcional
- Switch **Modo de Escaneamento Contínuo**.
- Switch **Som ao Escanear**.
- **Exportar Dados**: abre um menu para escolher CSV ou JSON; o arquivo é
  gerado e compartilhado via `share_plus` (salvar, enviar por e-mail, etc.).
- **Limpar Inventário Atual**: apaga todos os registros, com diálogo de
  confirmação.

### 5. Tela de Resumo / Dashboard
- Indicadores em tempo real: total de itens contados (soma das
  quantidades), total de registros feitos e localizações distintas
  visitadas.
- Lista de atividade recente (últimos 5 registros).

### Calculadora de quantidade
- Aba "Por Camadas" com cálculo automático:
  `(caixas por camada × camadas completas) + camada incompleta + extras`.
- Botão "USAR QUANTIDADE" retorna o valor calculado para o campo
  Quantidade da tela de Inventário.

## Próximos passos sugeridos

- Persistir os itens localmente entre sessões (ex: `sqflite`, `hive` ou
  `shared_preferences` para listas pequenas).
- Implementar a lógica da aba "Por Pallet" na Calculadora.
- Adicionar autenticação/troca real de inventariante no botão "Alterar".
- Gráficos visuais na aba Resumo (ex: `fl_chart`).
