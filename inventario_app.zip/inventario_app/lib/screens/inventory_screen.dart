import 'package:flutter/material.dart';
import '../models/inventory_item.dart';
import '../theme/app_colors.dart';
import '../widgets/stepper_field.dart';
import 'calculator_screen.dart';

/// Tela principal de Inventário: escaneamento de código de barras,
/// preenchimento de posição/quantidade e listagem dos últimos itens.
class InventoryScreen extends StatefulWidget {
  const InventoryScreen({super.key});

  @override
  State<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends State<InventoryScreen> {
  final TextEditingController _barcodeController = TextEditingController();
  final TextEditingController _locationController = TextEditingController();

  int _quantity = 1;

  // Lista de itens recentes (dados fictícios iniciais).
  final List<InventoryItem> _recentItems = [
    InventoryItem(
      barcode: '7891000100103',
      quantity: 24,
      location: 'A-12-03',
      addedAt: DateTime.now().subtract(const Duration(minutes: 4)),
    ),
    InventoryItem(
      barcode: '7891000315507',
      quantity: 85,
      location: 'B-04-11',
      addedAt: DateTime.now().subtract(const Duration(minutes: 19)),
    ),
    InventoryItem(
      barcode: '7896004008018',
      quantity: 12,
      location: 'C-07-02',
      addedAt: DateTime.now().subtract(const Duration(hours: 1, minutes: 5)),
    ),
  ];

  @override
  void dispose() {
    _barcodeController.dispose();
    _locationController.dispose();
    super.dispose();
  }

  void _incrementQuantity() => setState(() => _quantity++);

  void _decrementQuantity() {
    if (_quantity > 0) setState(() => _quantity--);
  }

  Future<void> _openCalculator() async {
    final result = await Navigator.push<int>(
      context,
      MaterialPageRoute(builder: (_) => const CalculatorScreen()),
    );
    if (result != null) {
      setState(() => _quantity = result);
    }
  }

  void _addItem() {
    if (_barcodeController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Escaneie ou informe um código antes de adicionar.')),
      );
      return;
    }

    final newItem = InventoryItem(
      barcode: _barcodeController.text.trim(),
      quantity: _quantity,
      location: _locationController.text.trim().isEmpty
          ? '-'
          : _locationController.text.trim(),
      addedAt: DateTime.now(),
    );

    setState(() {
      _recentItems.insert(0, newItem);
      _barcodeController.clear();
      _locationController.clear();
      _quantity = 1;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Item adicionado com sucesso!')),
    );
  }

  void _simulateScan() {
    // Simula a leitura de um código de barras (integração real usaria
    // um pacote como mobile_scanner).
    setState(() {
      _barcodeController.text =
          '78${DateTime.now().millisecondsSinceEpoch.toString().substring(3, 12)}';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          _buildHeader(context),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _buildUserCard(),
                  const SizedBox(height: 16),
                  _buildScanButton(),
                  const SizedBox(height: 20),
                  _buildBarcodeField(),
                  const SizedBox(height: 14),
                  _buildLocationField(),
                  const SizedBox(height: 14),
                  _buildQuantityRow(),
                  const SizedBox(height: 20),
                  _buildAddButton(),
                  const SizedBox(height: 28),
                  _buildRecentHeader(),
                  const SizedBox(height: 12),
                  _buildRecentList(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------
  // Header
  // ---------------------------------------------------------------------
  Widget _buildHeader(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 12,
        bottom: 16,
        left: 8,
        right: 8,
      ),
      decoration: const BoxDecoration(
        color: AppColors.primaryBlue,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(18)),
      ),
      child: Row(
        children: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.menu, color: Colors.white),
          ),
          const Expanded(
            child: Text(
              'Inventário',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.cloud_outlined, color: Colors.white),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------
  // Card do usuário
  // ---------------------------------------------------------------------
  Widget _buildUserCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(14),
        boxShadow: AppColors.softShadow,
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 22,
            backgroundColor: AppColors.primaryBlueLight,
            child: const Icon(Icons.person, color: AppColors.primaryBlue),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text(
                  'Inventariante',
                  style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
                ),
                SizedBox(height: 2),
                Text(
                  'Pedro Henrique',
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
              ],
            ),
          ),
          TextButton(
            onPressed: () {},
            style: TextButton.styleFrom(
              backgroundColor: AppColors.primaryBlueLight,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            ),
            child: const Text(
              'Alterar',
              style: TextStyle(
                color: AppColors.primaryBlue,
                fontWeight: FontWeight.w600,
                fontSize: 13,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------
  // Botão de escanear
  // ---------------------------------------------------------------------
  Widget _buildScanButton() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        boxShadow: AppColors.buttonShadow(AppColors.primaryBlue),
      ),
      child: ElevatedButton.icon(
        onPressed: _simulateScan,
        icon: const Icon(Icons.qr_code_scanner, size: 22),
        label: const Text('ESCANEAR CÓDIGO DE BARRAS'),
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primaryBlue,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 18),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          elevation: 0,
          textStyle: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.3,
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------
  // Campos de input
  // ---------------------------------------------------------------------
  Widget _buildBarcodeField() {
    return _InputCard(
      label: 'Código Escaneado',
      controller: _barcodeController,
      hint: 'Aguardando leitura...',
      trailingIcon: Icons.copy_outlined,
      onTrailingTap: () {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Código copiado.')),
        );
      },
    );
  }

  Widget _buildLocationField() {
    return _InputCard(
      label: 'Posição / Localização',
      controller: _locationController,
      hint: 'Ex: A-12-03',
      trailingIcon: Icons.location_on_outlined,
    );
  }

  Widget _buildQuantityRow() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Expanded(
          child: StepperField(
            label: 'Quantidade',
            value: _quantity,
            onChanged: (v) => setState(() => _quantity = v),
          ),
        ),
        const SizedBox(width: 10),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 6 + 13 + 6), // alinha com o label acima
            Container(
              height: 48,
              width: 52,
              decoration: BoxDecoration(
                color: AppColors.primaryBlueLight,
                borderRadius: BorderRadius.circular(10),
              ),
              child: InkWell(
                borderRadius: BorderRadius.circular(10),
                onTap: _openCalculator,
                child: const Icon(Icons.calculate_outlined,
                    color: AppColors.primaryBlue),
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ---------------------------------------------------------------------
  // Botão adicionar
  // ---------------------------------------------------------------------
  Widget _buildAddButton() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        boxShadow: AppColors.buttonShadow(AppColors.primaryGreen),
      ),
      child: ElevatedButton.icon(
        onPressed: _addItem,
        icon: const Icon(Icons.check_circle_outline, size: 22),
        label: const Text('ADICIONAR ITEM'),
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primaryGreen,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 18),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          elevation: 0,
          textStyle: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.3,
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------
  // Lista de itens recentes
  // ---------------------------------------------------------------------
  Widget _buildRecentHeader() {
    return Row(
      children: [
        const Expanded(
          child: Text(
            'Últimos itens adicionados',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
        ),
        TextButton(
          onPressed: () {},
          child: const Text(
            'Ver todos',
            style: TextStyle(
              color: AppColors.primaryBlue,
              fontWeight: FontWeight.w600,
              fontSize: 13,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildRecentList() {
    if (_recentItems.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 24),
        child: Center(
          child: Text(
            'Nenhum item adicionado ainda.',
            style: TextStyle(color: AppColors.textSecondary),
          ),
        ),
      );
    }

    return ListView.separated(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: _recentItems.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, index) {
        final item = _recentItems[index];
        return _RecentItemTile(item: item);
      },
    );
  }
}

/// Card de input padrão com rótulo e ícone de ação à direita.
class _InputCard extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final String hint;
  final IconData trailingIcon;
  final VoidCallback? onTrailingTap;

  const _InputCard({
    required this.label,
    required this.controller,
    required this.hint,
    required this.trailingIcon,
    this.onTrailingTap,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: AppColors.textSecondary,
          ),
        ),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(
            color: AppColors.cardBackground,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.border),
          ),
          child: TextField(
            controller: controller,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(color: AppColors.textHint, fontSize: 14),
              border: InputBorder.none,
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
              suffixIcon: IconButton(
                icon: Icon(trailingIcon, color: AppColors.primaryBlue, size: 20),
                onPressed: onTrailingTap,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

/// Item da lista de "Últimos itens adicionados".
class _RecentItemTile extends StatelessWidget {
  final InventoryItem item;

  const _RecentItemTile({required this.item});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(12),
        boxShadow: AppColors.softShadow,
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: AppColors.primaryBlueLight,
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.inventory_2_outlined,
                color: AppColors.primaryBlue, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.barcode,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'Local: ${item.location}',
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                'Qtd: ${item.quantity}',
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: AppColors.primaryGreenDark,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                item.formattedTime,
                style: const TextStyle(
                  fontSize: 11,
                  color: AppColors.textHint,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
