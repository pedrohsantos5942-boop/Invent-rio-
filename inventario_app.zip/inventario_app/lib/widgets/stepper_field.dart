import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

/// Campo numérico com botões de incremento/decremento nas laterais.
/// Usado tanto na tela de Inventário (Quantidade) quanto na
/// Calculadora (Caixas por camada, Camadas completas, etc).
class StepperField extends StatelessWidget {
  final String? label;
  final int value;
  final ValueChanged<int> onChanged;
  final int min;
  final int step;

  const StepperField({
    super.key,
    this.label,
    required this.value,
    required this.onChanged,
    this.min = 0,
    this.step = 1,
  });

  void _decrement() {
    final next = value - step;
    onChanged(next < min ? min : next);
  }

  void _increment() => onChanged(value + step);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (label != null) ...[
          Text(
            label!,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: AppColors.textSecondary,
            ),
          ),
          const SizedBox(height: 6),
        ],
        Container(
          height: 48,
          decoration: BoxDecoration(
            color: AppColors.cardBackground,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.border),
          ),
          child: Row(
            children: [
              _StepperButton(icon: Icons.remove, onTap: _decrement),
              Expanded(
                child: Center(
                  child: Text(
                    '$value',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ),
              ),
              _StepperButton(icon: Icons.add, onTap: _increment),
            ],
          ),
        ),
      ],
    );
  }
}

class _StepperButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _StepperButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        width: 44,
        height: 48,
        alignment: Alignment.center,
        child: Icon(icon, size: 20, color: AppColors.primaryBlue),
      ),
    );
  }
}
