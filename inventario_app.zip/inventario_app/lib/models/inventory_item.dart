/// Representa um item adicionado ao inventário.
class InventoryItem {
  final String barcode;
  final int quantity;
  final String location;
  final DateTime addedAt;

  InventoryItem({
    required this.barcode,
    required this.quantity,
    required this.location,
    required this.addedAt,
  });

  /// Retorna o horário formatado (HH:mm) para exibição na lista.
  String get formattedTime {
    final hour = addedAt.hour.toString().padLeft(2, '0');
    final minute = addedAt.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }
}
