# Inventário de Estoque — App Flutter

App mobile para inventário de estoque com escaneamento de código de barras
(simulado) e calculadora de quantidade por camadas/pallet.

## Estrutura do projeto

```
lib/
├── main.dart                     # Ponto de entrada, tema do app
├── theme/
│   └── app_colors.dart           # Paleta de cores centralizada
├── models/
│   └── inventory_item.dart       # Modelo de dados de um item de inventário
├── widgets/
│   └── stepper_field.dart        # Campo numérico com botões +/- reutilizável
└── screens/
    ├── main_navigation.dart      # Shell com BottomNavigationBar (4 abas)
    ├── inventory_screen.dart     # Tela principal: Inventário
    ├── calculator_screen.dart    # Tela de Calculadora (overlay/modal)
    ├── list_screen.dart          # Aba Lista (placeholder)
    ├── summary_screen.dart       # Aba Resumo (placeholder)
    └── settings_screen.dart      # Aba Configurações (placeholder)
```

## Como rodar

1. Certifique-se de ter o Flutter SDK instalado (`flutter --version`).
2. Dentro da pasta do projeto, instale as dependências:
   ```bash
   flutter pub get
   ```
3. Rode o app em um emulador ou dispositivo conectado:
   ```bash
   flutter run
   ```

Se você já tem um projeto Flutter criado (`flutter create meu_app`), basta
substituir a pasta `lib/` e o arquivo `pubspec.yaml` pelos deste pacote.

## Funcionalidades implementadas

- **Navegação inferior** com 4 abas: Inventário, Lista, Resumo, Configurações.
  A tela inicial é sempre a de Inventário.
- **Tela de Inventário**:
  - Header azul com ícone de menu e nuvem.
  - Card do inventariante (Pedro Henrique) com botão "Alterar".
  - Botão "ESCANEAR CÓDIGO DE BARRAS" (simula a leitura preenchendo o campo
    de código — para leitura real, integre um pacote como `mobile_scanner`).
  - Campos de Código Escaneado, Posição/Localização e Quantidade (com +/-).
  - Botão de Calculadora ao lado da Quantidade, que abre a tela de
    Calculadora e retorna o valor calculado automaticamente.
  - Botão "ADICIONAR ITEM" que valida, limpa os campos e insere o novo item
    no topo da lista de "Últimos itens adicionados".
- **Tela de Calculadora**:
  - Abas "Por Camadas" (funcional) e "Por Pallet" (placeholder).
  - 4 campos com botões +/-: Caixas por camada, Camadas completas,
    Camada incompleta, Amarração/Extras.
  - Card de cálculo com fórmula e total atualizados em tempo real.
  - Botão "LIMPAR" e botão verde "USAR QUANTIDADE (N)" que fecha a tela e
    devolve o valor para o campo Quantidade da tela de Inventário.

## Próximos passos sugeridos

- Integrar leitura real de código de barras (`mobile_scanner` ou `flutter_barcode_scanner`).
- Persistir os itens localmente (ex: `sqflite`, `hive`) ou via API.
- Implementar gráficos reais na aba Resumo (ex: `fl_chart`).
- Implementar a lógica da aba "Por Pallet" na Calculadora.
