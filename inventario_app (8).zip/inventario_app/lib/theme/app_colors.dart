import 'package:flutter/material.dart';

/// Paleta de cores centralizada do app — tema Preto e Laranja:
/// - Preto escuro (#1E1E1E) para headers, backgrounds escuros
/// - Laranja vibrante (#FF6B00) para botões, destaques, seleções
/// 
/// Inclui aliases de compatibilidade para telas existentes que usam
/// primaryBlue, primaryGreen, primaryBlueLight (remapeados para nova paleta).
class AppColors {
  AppColors._();

  // =========================================================================
  // Cores Principais: Preto e Laranja
  // =========================================================================
  static const Color primaryBlack = Color(0xFF1E1E1E);
  static const Color primaryOrange = Color(0xFFFF6B00);
  static const Color primaryOrangeDark = Color(0xFFE55A00);
  static const Color primaryOrangeLight = Color(0xFFFFE5CC);

  // =========================================================================
  // Cores de Feedback/Status
  // =========================================================================
  static const Color successGreen = Color(0xFF34A853);
  static const Color errorRed = Color(0xFFD32F2F);

  // =========================================================================
  // Backgrounds
  // =========================================================================
  static const Color background = Color(0xFF121212);
  static const Color cardBackground = Color(0xFF2A2A2A);
  static const Color lightGrey = Color(0xFF3A3A3A);
  static const Color darkCard = Color(0xFF2A2A2A);

  // =========================================================================
  // Textos
  // =========================================================================
  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xFFB0B0B0);
  static const Color textHint = Color(0xFF808080);

  // =========================================================================
  // Bordas e Dividers
  // =========================================================================
  static const Color border = Color(0xFF404040);
  static const Color pendingGrey = Color(0xFF707070);

  // =========================================================================
  // ALIASES DE COMPATIBILIDADE (para telas antigas)
  // Remapeiam cores antigas (azul/verde) para nova paleta (laranja/preto)
  // =========================================================================

  /// Alias: primaryGreen → primaryOrange
  /// Usado em: calculator_screen, summary_screen, etc.
  /// Nova semântica: ações primárias e sucesso agora em laranja
  static const Color primaryGreen = primaryOrange;

  /// Alias: primaryGreenDark → primaryOrangeDark
  /// Usado em: hover/pressed states de botões verdes antigos
  static const Color primaryGreenDark = primaryOrangeDark;

  /// Alias: primaryBlue → primaryBlack
  /// Usado em: headers, backgrounds escuros, ícones primários
  static const Color primaryBlue = primaryBlack;

  /// Alias: primaryBlueDark → primaryOrange (para destaques)
  /// Usado em: hover/focus states de elementos azuis antigos
  static const Color primaryBlueDark = primaryOrange;

  /// Alias: primaryBlueLight → lightGrey (para backgrounds/highlights leves)
  /// Usado em: backgrounds leves de ícones em calculator, etc.
  static const Color primaryBlueLight = lightGrey;

  // =========================================================================
  // Sombras
  // =========================================================================
  static List<BoxShadow> softShadow = [
    BoxShadow(
      color: Colors.black.withOpacity(0.3),
      blurRadius: 12,
      offset: const Offset(0, 4),
    ),
  ];

  static List<BoxShadow> buttonShadow(Color color) => [
        BoxShadow(
          color: color.withOpacity(0.35),
          blurRadius: 10,
          offset: const Offset(0, 4),
        ),
      ];
}
