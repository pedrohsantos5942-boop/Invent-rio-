# Compatibilidade de Cores — Transição Azul/Verde → Preto/Laranja

## Problema Resolvido

Durante a reformulação visual (Preto + Laranja), as telas antigas ainda faziam referência a cores que foram removidas da paleta:
- `primaryBlue`
- `primaryGreen`
- `primaryBlueLight`
- `primaryBlueDark`
- `primaryGreenDark`

Isso causava erros de compilação: `Member not found` no Flutter Actions.

## Solução: Aliases de Compatibilidade

Em vez de alterar todas as telas individualmente, adicionamos **aliases** no arquivo `lib/theme/app_colors.dart` que remapeiam as cores antigas para a nova paleta.

## Mapeamento de Cores

```
ANTIGA                    →  NOVA                    SIGNIFICADO
─────────────────────────────────────────────────────────────────
primaryGreen              →  primaryOrange           Ações principais, botões CTA
primaryGreenDark          →  primaryOrangeDark       Hover/pressed state
primaryBlue               →  primaryBlack            Headers, backgrounds escuros
primaryBlueDark           →  primaryOrange           Destaques, focus states
primaryBlueLight          →  lightGrey               Backgrounds leves de ícones
```

## Telas Afetadas

As seguintes telas continuam funcionando **sem alterações de código** graças aos aliases:

| Arquivo | Cores Usadas | Status |
|---------|--------------|--------|
| `barcode_scanner_screen.dart` | `primaryGreen` | ✅ Funciona |
| `calculator_screen.dart` | `primaryBlue`, `primaryBlueLight` | ✅ Funciona |
| `summary_screen.dart` | `primaryBlue`, `primaryGreen`, `primaryOrange` | ✅ Funciona |
| `settings_screen.dart` | `primaryBlue`, `primaryGreen`, `primaryOrange` | ✅ Funciona |
| `list_screen.dart` | `primaryBlue` | ✅ Funciona |

## Implementação

```dart
// Em lib/theme/app_colors.dart

// Cores novas
static const Color primaryOrange = Color(0xFFFF6B00);
static const Color primaryBlack = Color(0xFF1E1E1E);

// Aliases (compatibilidade)
static const Color primaryGreen = primaryOrange;
static const Color primaryBlue = primaryBlack;
static const Color primaryBlueLight = lightGrey;
// ... etc
```

Quando uma tela antiga faz referência a `AppColors.primaryGreen`, ela recebe automaticamente `primaryOrange` em tempo de compilação.

## Vantagens

✅ **Sem reescrever telas:** Código legado continua funcionando  
✅ **Transição gradual:** Podemos refatorar telas uma por uma  
✅ **Único ponto de controle:** Todas as cores em `app_colors.dart`  
✅ **Documentação clara:** Comentários explicam cada alias  

## Build Actions — Resolução

O erro `Member not found` foi resolvido porque:

1. **Antes:** `AppColors.primaryGreen` não existia → erro de compilação
2. **Depois:** `AppColors.primaryGreen` agora aponta para `AppColors.primaryOrange` → compila normalmente

## Próximos Passos (Opcional)

No futuro, podemos refatorar telas antigas gradualmente:

```dart
// ANTES (usando alias)
Container(
  color: AppColors.primaryBlue,  // É um alias para primaryBlack
)

// DEPOIS (usando nome semântico correto)
Container(
  color: AppColors.primaryBlack,  // Nome explícito
)
```

Isso melhora legibilidade sem quebrar nada neste momento.

---

**Status:** ✅ Build está funcionando com compatibilidade total  
**Alteração:** 19 de Agosto de 2026
