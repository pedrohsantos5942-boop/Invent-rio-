import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../models/inventory_item.dart';

class InventoryProvider extends ChangeNotifier {
  final List<InventoryItem> _items = [];

  final List<OperatorProfile> _operators = [
    const OperatorProfile(name: 'Pedro Henrique', role: 'Operador de Estoque'),
  ];
  String _activeOperator = 'Pedro Henrique';
  String _activeDeposit = 'Depósito Principal';

  bool _continuousScanMode = false;
  bool _soundOnScan = true;

  bool get continuousScanMode => _continuousScanMode;
  bool get soundOnScan => _soundOnScan;
  List<OperatorProfile> get operators => List.unmodifiable(_operators);
  String get activeOperator => _activeOperator;
  String get activeOperatorRole =>
      _operators.firstWhere(
        (o) => o.name == _activeOperator,
        orElse: () => const OperatorProfile(
          name: 'Pedro Henrique',
          role: 'Operador de Estoque',
        ),
      ).role;
  String get activeDeposit => _activeDeposit;

  void setContinuousScanMode(bool value) {
    _continuousScanMode = value;
    notifyListeners();
  }

  void setSoundOnScan(bool value) {
    _soundOnScan = value;
    notifyListeners();
  }

  void setActiveOperator(String name) {
    if (_operators.any((o) => o.name == name)) {
      _activeOperator = name;
      notifyListeners();
    }
  }

  void addOperator(String name, String role) {
    final cleanName = name.trim();
    final cleanRole = role.trim();
    if (cleanName.isEmpty || cleanRole.isEmpty) return;
    if (_operators.any((o) => o.name.toLowerCase() == cleanName.toLowerCase())) {
      return;
    }
    _operators.add(OperatorProfile(name: cleanName, role: cleanRole));
    notifyListeners();
  }

  void removeOperator(String name) {
    if (name == 'Pedro Henrique') return;
    _operators.removeWhere((o) => o.name == name);
    if (_activeOperator == name) _activeOperator = 'Pedro Henrique';
    notifyListeners();
  }

  void setActiveDeposit(String deposit) {
    _activeDeposit = deposit.trim().isEmpty ? 'Depósito Principal' : deposit.trim();
    notifyListeners();
  }

  List<InventoryItem> get items => List.unmodifiable(_items);
  List<InventoryItem> get recentItems => _items.take(3).toList();
  int get totalRecords => _items.length;
  int get totalUnitsCounted =>
      _items.fold<int>(0, (sum, item) => sum + item.quantity);
  int get uniqueLocationsCount => _items
      .map((e) => e.location.trim().toLowerCase())
      .where((l) => l.isNotEmpty && l != '-')
      .toSet()
      .length;

  void addItem(InventoryItem item) {
    _items.insert(0, item);
    notifyListeners();
  }

  void removeItem(String id) {
    _items.removeWhere((e) => e.id == id);
    notifyListeners();
  }

  void clearAll() {
    _items.clear();
    notifyListeners();
  }

  List<InventoryItem> search(String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return items;
    return _items
        .where((e) =>
            e.barcode.toLowerCase().contains(q) ||
            e.location.toLowerCase().contains(q))
        .toList();
  }

  String exportAsJson() => const JsonEncoder.withIndent('  ')
      .convert(_items.map((e) => e.toJson()).toList());

  String exportAsCsv() {
    final buffer = StringBuffer()..writeln(InventoryItem.csvHeader);
    for (final item in _items) {
      buffer.writeln(item.toCsvRow());
    }
    return buffer.toString();
  }
}

class OperatorProfile {
  final String name;
  final String role;

  const OperatorProfile({required this.name, required this.role});
}
