import 'package:flutter/material.dart';

/// Paleta visual oficial do aplicativo: Preto + Laranja.
class AppColors {
  AppColors._();

  static const Color primaryOrange = Color(0xFFFF6B00);
  static const Color primaryOrangeDark = Color(0xFFE85D00);
  static const Color primaryOrangeLight = Color(0xFFFFE8D6);

  static const Color black = Color(0xFF1E1E1E);
  static const Color blackSoft = Color(0xFF252525);
  static const Color background = Color(0xFFF5F5F5);
  static const Color cardBackground = Colors.white;
  static const Color lightGrey = Color(0xFFEEEEEE);

  static const Color textPrimary = Color(0xFF1E1E1E);
  static const Color textSecondary = Color(0xFF666666);
  static const Color textHint = Color(0xFF9E9E9E);
  static const Color border = Color(0xFFD9D9D9);

  // Aliases mantidos para compatibilidade com telas existentes.
  static const Color primaryBlue = primaryOrange;
  static const Color primaryBlueDark = primaryOrangeDark;
  static const Color primaryBlueLight = primaryOrangeLight;
  static const Color primaryGreen = primaryOrange;
  static const Color primaryGreenDark = primaryOrangeDark;

  static List<BoxShadow> softShadow = [
    BoxShadow(
      color: Colors.black.withOpacity(0.08),
      blurRadius: 12,
      offset: const Offset(0, 4),
    ),
  ];

  static List<BoxShadow> buttonShadow(Color color) => [
        BoxShadow(
          color: color.withOpacity(0.30),
          blurRadius: 10,
          offset: const Offset(0, 4),
        ),
      ];
}
