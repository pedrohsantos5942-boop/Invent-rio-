import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../providers/inventory_provider.dart';
import '../theme/app_colors.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _exportData(BuildContext context, {required bool asJson}) async {
    final provider = context.read<InventoryProvider>();
    if (provider.totalRecords == 0) {
      _message(context, 'Não há itens para exportar.');
      return;
    }

    final content = asJson ? provider.exportAsJson() : provider.exportAsCsv();
    final extension = asJson ? 'json' : 'csv';
    try {
      final dir = await getTemporaryDirectory();
      final file = File(
        '${dir.path}/inventario_${DateTime.now().millisecondsSinceEpoch}.$extension',
      );
      await file.writeAsString(content);
      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Exportação do inventário (${provider.totalRecords} itens)',
      );
    } catch (_) {
      if (context.mounted) _message(context, 'Erro ao exportar.');
    }
  }

  void _message(BuildContext context, String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _confirmClearAll(BuildContext context) async {
    final provider = context.read<InventoryProvider>();
    if (provider.totalRecords == 0) {
      _message(context, 'O inventário já está vazio.');
      return;
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Limpar inventário atual'),
        content: Text(
          'Esta ação apagará os ${provider.totalRecords} itens registrados. Deseja continuar?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Limpar tudo'),
          ),
        ],
      ),
    );

    if (confirmed == true && context.mounted) {
      provider.clearAll();
      _message(context, 'Inventário limpo com sucesso.');
    }
  }

  void _showExportSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.cardBackground,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 4, 20, 10),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Exportar dados do inventário',
                  style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.table_chart_outlined, color: AppColors.primaryOrange),
              title: const Text('Exportar como CSV'),
              onTap: () {
                Navigator.pop(ctx);
                _exportData(context, asJson: false);
              },
            ),
            ListTile(
              leading: const Icon(Icons.data_object, color: AppColors.primaryOrange),
              title: const Text('Exportar como JSON'),
              onTap: () {
                Navigator.pop(ctx);
                _exportData(context, asJson: true);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showAddOperatorDialog(BuildContext context) {
    final nameController = TextEditingController();
    final roleController =
        TextEditingController(text: 'Operador de Estoque');

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Novo Inventariante'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(
                labelText: 'Nome',
                hintText: 'Ex.: João Silva',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: roleController,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(
                labelText: 'Perfil / Cargo',
                hintText: 'Ex.: Operador de Estoque',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () {
              final provider = context.read<InventoryProvider>();
              if (nameController.text.trim().isEmpty ||
                  roleController.text.trim().isEmpty) {
                _message(context, 'Preencha nome e perfil.');
                return;
              }
              if (provider.operators.any(
                (o) => o.name.toLowerCase() == nameController.text.trim().toLowerCase(),
              )) {
                _message(context, 'Esse inventariante já está cadastrado.');
                return;
              }
              provider.addOperator(nameController.text, roleController.text);
              Navigator.pop(ctx);
              _message(context, 'Inventariante cadastrado com sucesso.');
            },
            child: const Text('Cadastrar'),
          ),
        ],
      ),
    ).whenComplete(() {
      nameController.dispose();
      roleController.dispose();
    });
  }

  void _showManageOperators(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.cardBackground,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (ctx) => Consumer<InventoryProvider>(
        builder: (_, provider, __) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const ListTile(
                  title: Text(
                    'Inventariantes cadastrados',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
                ...provider.operators.map(
                  (operator) => ListTile(
                    leading: const Icon(Icons.person_outline, color: AppColors.primaryOrange),
                    title: Text(operator.name),
                    subtitle: Text(operator.role),
                    trailing: operator.name == 'Pedro Henrique'
                        ? const Text('Padrão')
                        : IconButton(
                            tooltip: 'Remover',
                            icon: const Icon(Icons.delete_outline, color: Colors.red),
                            onPressed: () => provider.removeOperator(operator.name),
                          ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          _buildHeader(context),
          Expanded(
            child: Consumer<InventoryProvider>(
              builder: (context, provider, _) => ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  const _SectionLabel('Escaneamento'),
                  _SettingsCard(
                    children: [
                      _SwitchTile(
                        icon: Icons.qr_code_scanner,
                        title: 'Modo de escaneamento contínuo',
                        subtitle: 'Mantém a câmera aberta para ler vários códigos seguidos',
                        value: provider.continuousScanMode,
                        onChanged: provider.setContinuousScanMode,
                      ),
                      const Divider(height: 1, indent: 56),
                      _SwitchTile(
                        icon: Icons.volume_up_outlined,
                        title: 'Som ao escanear',
                        subtitle: 'Emite um bipe de confirmação a cada leitura',
                        value: provider.soundOnScan,
                        onChanged: provider.setSoundOnScan,
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  const _SectionLabel('Inventariantes'),
                  _SettingsCard(
                    children: [
                      _ActionTile(
                        icon: Icons.person_add_alt_1_outlined,
                        iconColor: AppColors.primaryOrange,
                        title: 'Gerenciar / Inserir Novos Inventariantes',
                        subtitle: '${provider.operators.length} operador(es) cadastrado(s)',
                        onTap: () => _showAddOperatorDialog(context),
                      ),
                      const Divider(height: 1, indent: 56),
                      _ActionTile(
                        icon: Icons.manage_accounts_outlined,
                        iconColor: AppColors.primaryOrange,
                        title: 'Ver inventariantes cadastrados',
                        subtitle: 'Selecionar ou remover perfis',
                        onTap: () => _showManageOperators(context),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  const _SectionLabel('Dados'),
                  _SettingsCard(
                    children: [
                      _ActionTile(
                        icon: Icons.ios_share,
                        iconColor: AppColors.primaryOrange,
                        title: 'Exportar dados',
                        subtitle: '${provider.totalRecords} itens no inventário atual',
                        onTap: () => _showExportSheet(context),
                      ),
                      const Divider(height: 1, indent: 56),
                      _ActionTile(
                        icon: Icons.delete_outline,
                        iconColor: Colors.red,
                        title: 'Limpar inventário atual',
                        subtitle: 'Apaga todos os registros salvos da memória',
                        titleColor: Colors.red,
                        onTap: () => _confirmClearAll(context),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  const _SectionLabel('Sobre'),
                  _SettingsCard(
                    children: [
                      const _InfoTile(title: 'Versão do app', value: '1.0.0'),
                      const Divider(height: 1, indent: 56),
                      _InfoTile(title: 'Inventariante ativo', value: provider.activeOperator),
                      const Divider(height: 1, indent: 56),
                      _InfoTile(title: 'Depósito ativo', value: provider.activeDeposit),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 12,
        bottom: 16,
        left: 16,
        right: 16,
      ),
      decoration: const BoxDecoration(
        color: AppColors.black,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(18)),
      ),
      child: const Text(
        'Configurações',
        style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 8),
        child: Text(
          text.toUpperCase(),
          style: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w700,
            color: AppColors.textSecondary,
            letterSpacing: 0.6,
          ),
        ),
      );
}

class _SettingsCard extends StatelessWidget {
  final List<Widget> children;
  const _SettingsCard({required this.children});

  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(
          color: AppColors.cardBackground,
          borderRadius: BorderRadius.circular(14),
          boxShadow: AppColors.softShadow,
        ),
        child: Column(children: children),
      );
}

class _SwitchTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  const _SwitchTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) => SwitchListTile(
        value: value,
        onChanged: onChanged,
        activeColor: AppColors.primaryOrange,
        secondary: Icon(icon, color: AppColors.primaryOrange),
        title: Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
      );
}

class _ActionTile extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String subtitle;
  final Color? titleColor;
  final VoidCallback onTap;

  const _ActionTile({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.titleColor,
  });

  @override
  Widget build(BuildContext context) => ListTile(
        onTap: onTap,
        leading: Icon(icon, color: iconColor),
        title: Text(
          title,
          style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: titleColor),
        ),
        subtitle: Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
        trailing: const Icon(Icons.chevron_right, color: AppColors.textHint),
      );
}

class _InfoTile extends StatelessWidget {
  final String title;
  final String value;
  const _InfoTile({required this.title, required this.value});

  @override
  Widget build(BuildContext context) => ListTile(
        leading: const Icon(Icons.info_outline, color: AppColors.textHint),
        title: Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        trailing: Flexible(
          child: Text(
            value,
            textAlign: TextAlign.end,
            style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
          ),
        ),
      );
}
