import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models/inventory_item.dart';
import '../providers/inventory_provider.dart';
import '../providers/navigation_provider.dart';
import '../theme/app_colors.dart';
import '../widgets/stepper_field.dart';
import 'barcode_scanner_screen.dart';
import 'calculator_screen.dart';

class InventoryScreen extends StatefulWidget {
  const InventoryScreen({super.key});

  @override
  State<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends State<InventoryScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final TextEditingController _barcodeController = TextEditingController();
  final TextEditingController _locationController = TextEditingController();
  final TextEditingController _filterController = TextEditingController();

  int _quantity = 0;

  @override
  void dispose() {
    _barcodeController.dispose();
    _locationController.dispose();
    _filterController.dispose();
    super.dispose();
  }

  Future<void> _openScanner() async {
    final provider = context.read<InventoryProvider>();
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => BarcodeScannerScreen(
          continuousMode: provider.continuousScanMode,
          soundEnabled: provider.soundOnScan,
          onDetected: (code) => setState(() => _barcodeController.text = code),
        ),
      ),
    );
  }

  Future<void> _openCalculator() async {
    final result = await Navigator.push<int>(
      context,
      MaterialPageRoute(builder: (_) => const CalculatorScreen()),
    );
    if (result != null) setState(() => _quantity = result);
  }

  void _confirmPosition() {
    if (_locationController.text.trim().isEmpty) {
      _showMessage('Informe a posição antes de confirmar.');
      return;
    }
    FocusScope.of(context).unfocus();
    _showMessage(
      'Posição "${_locationController.text.trim()}" confirmada.',
      color: AppColors.primaryOrange,
    );
  }

  void _addItem() {
    if (_barcodeController.text.trim().isEmpty) {
      _showMessage('Escaneie ou informe um código antes de adicionar.');
      return;
    }

    final newItem = InventoryItem(
      barcode: _barcodeController.text.trim(),
      quantity: _quantity,
      location: _locationController.text.trim().isEmpty
          ? '-'
          : _locationController.text.trim(),
      addedAt: DateTime.now(),
    );

    context.read<InventoryProvider>().addItem(newItem);

    setState(() {
      _barcodeController.clear();
      _locationController.clear();
      _quantity = 0;
    });

    _showMessage(
      'Item adicionado com sucesso!',
      color: AppColors.primaryOrange,
    );
  }

  void _showMessage(String message, {Color? color}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(backgroundColor: color, content: Text(message)),
    );
  }

  void _showCloudPending() {
    _showMessage(
      'Integração com o armazém será realizada em breve.',
      color: AppColors.black,
    );
  }

  void _showOperatorSelector() {
    final provider = context.read<InventoryProvider>();
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.cardBackground,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 0, 20, 10),
              child: Text(
                'Selecionar inventariante',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
              ),
            ),
            ...provider.operators.map(
              (operator) => ListTile(
                leading: CircleAvatar(
                  backgroundColor: AppColors.primaryOrangeLight,
                  child: const Icon(Icons.person, color: AppColors.primaryOrange),
                ),
                title: Text(operator.name),
                subtitle: Text(operator.role),
                trailing: operator.name == provider.activeOperator
                    ? const Icon(Icons.check, color: AppColors.primaryOrange)
                    : null,
                onTap: () {
                  provider.setActiveOperator(operator.name);
                  Navigator.pop(sheetContext);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _exportCount() async {
    final provider = context.read<InventoryProvider>();
    if (provider.totalRecords == 0) {
      _showMessage('Não há itens para exportar.');
      return;
    }
    try {
      final dir = await getTemporaryDirectory();
      final file = File(
        '${dir.path}/contagem_${DateTime.now().millisecondsSinceEpoch}.csv',
      );
      await file.writeAsString(provider.exportAsCsv());
      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Contagem do inventário (${provider.totalRecords} itens)',
      );
    } catch (e) {
      _showMessage('Erro ao exportar a contagem.');
    }
  }

  void _showDepositDialog() {
    final provider = context.read<InventoryProvider>();
    final controller = TextEditingController(text: provider.activeDeposit);
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Trocar Depósito'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(
            labelText: 'Depósito',
            hintText: 'Ex.: Depósito Principal',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () {
              provider.setActiveDeposit(controller.text);
              Navigator.pop(dialogContext);
            },
            child: const Text('Confirmar'),
          ),
        ],
      ),
    ).whenComplete(controller.dispose);
  }

  void _showImportSoon() {
    _showMessage(
      'Importação de Base (CSV) estará disponível em breve.',
      color: AppColors.black,
    );
  }

  void _showExit() {
    _showMessage(
      'Sessão de operador encerrada. O app continuará aberto para um novo operador.',
      color: AppColors.black,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: AppColors.background,
      drawer: _buildDrawer(),
      body: Column(
        children: [
          _buildHeader(),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _buildUserCard(),
                  const SizedBox(height: 16),
                  _buildScanButton(),
                  const SizedBox(height: 20),
                  _buildBarcodeField(),
                  const SizedBox(height: 14),
                  _buildLocationRow(),
                  const SizedBox(height: 14),
                  _buildQuantityRow(),
                  const SizedBox(height: 20),
                  _buildAddButton(),
                  const SizedBox(height: 28),
                  _buildRecentHeader(),
                  const SizedBox(height: 12),
                  _buildFilterField(),
                  const SizedBox(height: 12),
                  _buildRecentList(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 8,
        bottom: 10,
        left: 8,
        right: 8,
      ),
      decoration: const BoxDecoration(
        color: AppColors.black,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(18)),
      ),
      child: Row(
        children: [
          IconButton(
            tooltip: 'Menu',
            onPressed: () => _scaffoldKey.currentState?.openDrawer(),
            icon: const Icon(Icons.menu, color: Colors.white),
          ),
          const Expanded(
            child: Text(
              'Gestão de Inventário',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          IconButton(
            tooltip: 'Integração pendente',
            onPressed: _showCloudPending,
            icon: const Icon(Icons.cloud_off, color: AppColors.primaryOrange),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: AppColors.cardBackground,
      child: SafeArea(
        child: Column(
          children: [
            Consumer<InventoryProvider>(
              builder: (_, provider, __) => Container(
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(20, 22, 20, 20),
                color: AppColors.black,
                child: Row(
                  children: [
                    const CircleAvatar(
                      radius: 28,
                      backgroundColor: AppColors.primaryOrange,
                      child: Icon(Icons.person, color: Colors.white, size: 30),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            provider.activeOperator,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 17,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            provider.activeOperatorRole,
                            style: const TextStyle(
                              color: Colors.white70,
                              fontSize: 13,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            provider.activeDeposit,
                            style: const TextStyle(
                              color: AppColors.primaryOrange,
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.warehouse_outlined, color: AppColors.primaryOrange),
              title: const Text('Trocar Depósito'),
              onTap: () {
                Navigator.pop(context);
                _showDepositDialog();
              },
            ),
            ListTile(
              leading: const Icon(Icons.file_upload_outlined, color: AppColors.primaryOrange),
              title: const Text('Importar Base (CSV)'),
              onTap: () {
                Navigator.pop(context);
                _showImportSoon();
              },
            ),
            ListTile(
              leading: const Icon(Icons.file_download_outlined, color: AppColors.primaryOrange),
              title: const Text('Exportar Contagem'),
              onTap: () {
                Navigator.pop(context);
                _exportCount();
              },
            ),
            const Divider(),
            Consumer<InventoryProvider>(
              builder: (_, provider, __) => SwitchListTile(
                secondary: const Icon(Icons.qr_code_scanner, color: AppColors.primaryOrange),
                title: const Text('Modo Bipador Contínuo'),
                subtitle: const Text('Escanear vários códigos em sequência'),
                value: provider.continuousScanMode,
                activeColor: AppColors.primaryOrange,
                onChanged: provider.setContinuousScanMode,
              ),
            ),
            const Spacer(),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.logout, color: AppColors.primaryOrange),
              title: const Text('Sair'),
              onTap: () {
                Navigator.pop(context);
                _showExit();
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildUserCard() {
    return Consumer<InventoryProvider>(
      builder: (context, provider, _) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.cardBackground,
          borderRadius: BorderRadius.circular(14),
          boxShadow: AppColors.softShadow,
        ),
        child: Row(
          children: [
            const CircleAvatar(
              radius: 22,
              backgroundColor: AppColors.primaryOrangeLight,
              child: Icon(Icons.person, color: AppColors.primaryOrange),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Inventariante',
                    style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    provider.activeOperator,
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ],
              ),
            ),
            TextButton(
              onPressed: _showOperatorSelector,
              child: const Text(
                'Alterar',
                style: TextStyle(
                  color: AppColors.primaryOrange,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildScanButton() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        boxShadow: AppColors.buttonShadow(AppColors.primaryOrange),
      ),
      child: ElevatedButton.icon(
        onPressed: _openScanner,
        icon: const Icon(Icons.qr_code_scanner, size: 22),
        label: const Text('ESCANEAR CÓDIGO DE BARRAS'),
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primaryOrange,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 18),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          elevation: 0,
          textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
        ),
      ),
    );
  }

  Widget _buildBarcodeField() {
    return _LabeledField(
      label: 'Código escaneado',
      child: TextField(
        controller: _barcodeController,
        decoration: InputDecoration(
          hintText: 'Aguardando leitura...',
          hintStyle: const TextStyle(color: AppColors.textHint, fontSize: 14),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          suffixIcon: IconButton(
            icon: const Icon(Icons.copy_outlined, color: AppColors.primaryOrange, size: 20),
            onPressed: () => _showMessage('Código copiado.'),
          ),
        ),
      ),
    );
  }

  Widget _buildLocationRow() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Posição / Location',
          style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textSecondary),
        ),
        const SizedBox(height: 6),
        Row(
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: AppColors.cardBackground,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppColors.border),
                ),
                child: TextField(
                  controller: _locationController,
                  decoration: const InputDecoration(
                    hintText: 'Ex: H105',
                    hintStyle: TextStyle(color: AppColors.textHint, fontSize: 14),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                    suffixIcon: Icon(Icons.location_on_outlined, color: AppColors.primaryOrange),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: ElevatedButton(
                onPressed: _confirmPosition,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryOrange,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  elevation: 0,
                ),
                child: const Text(
                  'Confirmar Posição',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildQuantityRow() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Quantidade',
          style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textSecondary),
        ),
        const SizedBox(height: 6),
        Row(
          children: [
            Expanded(
              flex: 3,
              child: StepperField(
                value: _quantity,
                onChanged: (v) => setState(() => _quantity = v),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              flex: 2,
              child: OutlinedButton.icon(
                onPressed: _openCalculator,
                icon: const Icon(Icons.calculate_outlined, size: 18),
                label: const Text('Calculadora'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.primaryOrange,
                  backgroundColor: AppColors.primaryOrangeLight,
                  side: const BorderSide(color: AppColors.primaryOrangeLight),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildAddButton() {
    return ElevatedButton.icon(
      onPressed: _addItem,
      icon: const Icon(Icons.check_circle_outline, size: 22),
      label: const Text('ADICIONAR ITEM'),
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.primaryOrange,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 18),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        elevation: 0,
        textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
      ),
    );
  }

  Widget _buildRecentHeader() {
    return Row(
      children: [
        const Expanded(
          child: Text(
            'Últimos itens adicionados',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
          ),
        ),
        TextButton(
          onPressed: () => context.read<NavigationProvider>().setIndex(1),
          child: const Text(
            'Ver todos',
            style: TextStyle(color: AppColors.primaryOrange, fontWeight: FontWeight.w600, fontSize: 13),
          ),
        ),
      ],
    );
  }

  Widget _buildFilterField() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.border),
      ),
      child: TextField(
        controller: _filterController,
        onChanged: (_) => setState(() {}),
        decoration: const InputDecoration(
          hintText: 'Filtrar por localização ou código...',
          hintStyle: TextStyle(color: AppColors.textHint, fontSize: 13),
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          prefixIcon: Icon(Icons.search, color: AppColors.textHint, size: 20),
        ),
      ),
    );
  }

  Widget _buildRecentList() {
    return Consumer<InventoryProvider>(
      builder: (context, provider, _) {
        final query = _filterController.text.trim().toLowerCase();
        var items = provider.recentItems;
        if (query.isNotEmpty) {
          items = items
              .where((e) =>
                  e.barcode.toLowerCase().contains(query) ||
                  e.location.toLowerCase().contains(query))
              .toList();
        }

        if (items.isEmpty) {
          return const Padding(
            padding: EdgeInsets.symmetric(vertical: 24),
            child: Center(
              child: Text(
                'Nenhum item adicionado ainda.',
                style: TextStyle(color: AppColors.textSecondary),
              ),
            ),
          );
        }

        return ListView.separated(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: items.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (context, index) => _RecentItemTile(item: items[index]),
        );
      },
    );
  }
}

class _LabeledField extends StatelessWidget {
  final String label;
  final Widget child;

  const _LabeledField({required this.label, required this.child});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textSecondary),
        ),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(
            color: AppColors.cardBackground,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.border),
          ),
          child: child,
        ),
      ],
    );
  }
}

class _RecentItemTile extends StatelessWidget {
  final InventoryItem item;

  const _RecentItemTile({required this.item});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(12),
        boxShadow: AppColors.softShadow,
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: AppColors.primaryOrangeLight,
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.inventory_2_outlined, color: AppColors.primaryOrange, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.barcode,
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                ),
                const SizedBox(height: 2),
                Text(
                  item.location,
                  style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '${item.quantity} un.',
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
              ),
              const SizedBox(height: 2),
              Text(
                item.formattedTime,
                style: const TextStyle(fontSize: 11, color: AppColors.textHint),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
