import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/inventory_provider.dart';
import '../theme/app_colors.dart';

/// Tela de Resumo / Dashboard: indicadores calculados em tempo real
/// a partir dos dados do [InventoryProvider].
class SummaryScreen extends StatelessWidget {
  const SummaryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          _buildHeader(context),
          Expanded(
            child: Consumer<InventoryProvider>(
              builder: (context, provider, _) {
                return SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _SummaryCard(
                        icon: Icons.inventory_2_outlined,
                        color: AppColors.primaryBlue,
                        label: 'Total de itens contados',
                        value: '${provider.totalUnitsCounted}',
                        subtitle: 'Soma de todas as quantidades registradas',
                      ),
                      const SizedBox(height: 14),
                      _SummaryCard(
                        icon: Icons.fact_check_outlined,
                        color: AppColors.primaryGreen,
                        label: 'Total de registros feitos',
                        value: '${provider.totalRecords}',
                        subtitle: 'Número de vezes que "Adicionar item" foi usado',
                      ),
                      const SizedBox(height: 14),
                      _SummaryCard(
                        icon: Icons.location_on_outlined,
                        color: Colors.orange,
                        label: 'Localizações visitadas',
                        value: '${provider.uniqueLocationsCount}',
                        subtitle: 'Posições distintas já registradas',
                      ),
                      const SizedBox(height: 24),
                      if (provider.totalRecords == 0)
                        const _EmptySummaryHint()
                      else
                        _buildRecentActivity(provider),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 12,
        bottom: 16,
        left: 16,
        right: 16,
      ),
      decoration: const BoxDecoration(
        color: AppColors.black,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(18)),
      ),
      child: const Text(
        'Resumo',
        style: TextStyle(
          color: Colors.white,
          fontSize: 18,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  Widget _buildRecentActivity(InventoryProvider provider) {
    final lastFive = provider.items.take(5).toList();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Atividade recente',
          style: TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 12),
        Container(
          decoration: BoxDecoration(
            color: AppColors.cardBackground,
            borderRadius: BorderRadius.circular(14),
            boxShadow: AppColors.softShadow,
          ),
          child: Column(
            children: List.generate(lastFive.length, (index) {
              final item = lastFive[index];
              return Column(
                children: [
                  ListTile(
                    dense: true,
                    leading: const Icon(Icons.check_circle_outline,
                        color: AppColors.primaryGreen, size: 20),
                    title: Text(
                      item.barcode,
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                    ),
                    subtitle: Text('${item.location} • ${item.quantity} un.'),
                    trailing: Text(
                      item.formattedTime,
                      style: const TextStyle(fontSize: 11, color: AppColors.textHint),
                    ),
                  ),
                  if (index != lastFive.length - 1)
                    const Divider(height: 1, indent: 16, endIndent: 16),
                ],
              );
            }),
          ),
        ),
      ],
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label;
  final String value;
  final String subtitle;

  const _SummaryCard({
    required this.icon,
    required this.color,
    required this.label,
    required this.value,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(14),
        boxShadow: AppColors.softShadow,
      ),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: color, size: 26),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: const TextStyle(fontSize: 11, color: AppColors.textHint),
                ),
              ],
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.w800,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

class _EmptySummaryHint extends StatelessWidget {
  const _EmptySummaryHint();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(14),
      ),
      child: const Column(
        children: [
          Icon(Icons.bar_chart, size: 40, color: AppColors.textHint),
          SizedBox(height: 12),
          Text(
            'Adicione itens na aba Inventário para ver os indicadores aqui.',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppColors.textSecondary),
          ),
        ],
      ),
    );
  }
}
