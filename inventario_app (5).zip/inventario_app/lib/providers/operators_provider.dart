import 'package:flutter/foundation.dart';

/// Modelo de um operador/inventariante do sistema.
class Operator {
  final String id;
  final String name;
  final String role; // ex: "Operador de Estoque", "Gerenciador", etc.

  Operator({required this.id, required this.name, required this.role});
}

/// Provider que gerencia a lista de operadores cadastrados e o operador
/// ativo no momento.
class OperatorsProvider extends ChangeNotifier {
  // Lista de operadores — começa com o padrão "Pedro Henrique"
  final List<Operator> _operators = [
    Operator(id: '1', name: 'Pedro Henrique', role: 'Operador de Estoque'),
  ];

  // ID do operador ativo
  String _activeOperatorId = '1';

  List<Operator> get operators => List.unmodifiable(_operators);

  Operator? get activeOperator => _operators.firstWhere(
        (op) => op.id == _activeOperatorId,
        orElse: () => Operator(id: '', name: 'Desconhecido', role: ''),
      );

  String get activeOperatorName => activeOperator?.name ?? 'N/A';
  String get activeOperatorRole => activeOperator?.role ?? 'N/A';

  void addOperator(String name, String role) {
    final newId = DateTime.now().millisecondsSinceEpoch.toString();
    _operators.add(
      Operator(id: newId, name: name, role: role),
    );
    notifyListeners();
  }

  void removeOperator(String id) {
    _operators.removeWhere((op) => op.id == id);
    // Se o operador ativo foi removido, seleciona o primeiro disponível
    if (_activeOperatorId == id && _operators.isNotEmpty) {
      _activeOperatorId = _operators.first.id;
    }
    notifyListeners();
  }

  void setActiveOperator(String id) {
    if (_operators.any((op) => op.id == id)) {
      _activeOperatorId = id;
      notifyListeners();
    }
  }

  /// Retorna o operador pelo ID, ou null se não encontrado.
  Operator? getOperatorById(String id) {
    try {
      return _operators.firstWhere((op) => op.id == id);
    } catch (_) {
      return null;
    }
  }
}
