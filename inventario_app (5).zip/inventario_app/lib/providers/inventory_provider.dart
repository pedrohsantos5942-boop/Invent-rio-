import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../models/inventory_item.dart';

/// Modelo simples de um inventariante/operador.
class Operator {
  final String id;
  final String name;
  final String role;

  Operator({required this.id, required this.name, this.role = 'Operador de Estoque'});

  factory Operator.fromJson(Map<String, dynamic> json) => Operator(
        id: json['id'] as String,
        name: json['name'] as String,
        role: json['role'] as String? ?? 'Operador de Estoque',
      );

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'role': role};
}

/// Gerenciador de estado global do app: mantém a lista real de itens
/// inventariados, as preferências de escaneamento e os operadores,
/// expostos a toda a árvore de widgets via Provider (ChangeNotifierProvider em main.dart).
class InventoryProvider extends ChangeNotifier {
  final List<InventoryItem> _items = [];

  // Operadores/inventariantes
  final List<Operator> _operators = [
    Operator(id: '1', name: 'Pedro Henrique', role: 'Operador de Estoque'),
  ];
  late String _currentOperatorId = _operators.first.id;

  // Depósito ativo
  String _currentWarehouse = 'Depósito Principal';

  // Configurações
  bool _continuousScanMode = false;
  bool _soundOnScan = true;

  // Getters
  bool get continuousScanMode => _continuousScanMode;
  bool get soundOnScan => _soundOnScan;
  List<Operator> get operators => List.unmodifiable(_operators);
  String get currentOperatorId => _currentOperatorId;
  Operator get currentOperator =>
      _operators.firstWhere((op) => op.id == _currentOperatorId);
  String get currentWarehouse => _currentWarehouse;

  void setContinuousScanMode(bool value) {
    _continuousScanMode = value;
    notifyListeners();
  }

  void setSoundOnScan(bool value) {
    _soundOnScan = value;
    notifyListeners();
  }

  void setCurrentOperator(String operatorId) {
    if (_operators.any((op) => op.id == operatorId)) {
      _currentOperatorId = operatorId;
      notifyListeners();
    }
  }

  void setCurrentWarehouse(String warehouse) {
    _currentWarehouse = warehouse;
    notifyListeners();
  }

  /// Adiciona um novo operador à lista.
  void addOperator(String name, {String role = 'Operador de Estoque'}) {
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    _operators.add(Operator(id: id, name: name, role: role));
    notifyListeners();
  }

  /// Remove um operador por ID (não permite remover o único operador).
  void removeOperator(String operatorId) {
    if (_operators.length > 1) {
      _operators.removeWhere((op) => op.id == operatorId);
      // Se o operador removido era o ativo, volta pro primeiro.
      if (_currentOperatorId == operatorId && _operators.isNotEmpty) {
        _currentOperatorId = _operators.first.id;
      }
      notifyListeners();
    }
  }

  // ---------------------------------------------------------------------
  // Itens de inventário
  // ---------------------------------------------------------------------

  /// Lista completa (mais recente primeiro), somente leitura.
  List<InventoryItem> get items => List.unmodifiable(_items);

  /// Últimos 3 itens adicionados, usados na tela principal.
  List<InventoryItem> get recentItems => _items.take(3).toList();

  int get totalRecords => _items.length;

  /// Soma de todas as quantidades registradas (total de itens contados).
  int get totalUnitsCounted =>
      _items.fold<int>(0, (sum, item) => sum + item.quantity);

  /// Quantidade de localizações distintas já visitadas.
  int get uniqueLocationsCount => _items
      .map((e) => e.location.trim().toLowerCase())
      .where((l) => l.isNotEmpty && l != '-')
      .toSet()
      .length;

  void addItem(InventoryItem item) {
    _items.insert(0, item);
    notifyListeners();
  }

  void removeItem(String id) {
    _items.removeWhere((e) => e.id == id);
    notifyListeners();
  }

  void clearAll() {
    _items.clear();
    notifyListeners();
  }

  /// Filtra itens por código de barras ou localização (case-insensitive).
  List<InventoryItem> search(String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return items;
    return _items
        .where((e) =>
            e.barcode.toLowerCase().contains(q) ||
            e.location.toLowerCase().contains(q))
        .toList();
  }

  // ---------------------------------------------------------------------
  // Exportação
  // ---------------------------------------------------------------------

  String exportAsJson() {
    return const JsonEncoder.withIndent('  ')
        .convert(_items.map((e) => e.toJson()).toList());
  }

  String exportAsCsv() {
    final buffer = StringBuffer()..writeln(InventoryItem.csvHeader);
    for (final item in _items) {
      buffer.writeln(item.toCsvRow());
    }
    return buffer.toString();
  }
}
