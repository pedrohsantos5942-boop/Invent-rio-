import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:permission_handler/permission_handler.dart';
import '../theme/app_colors.dart';

/// Tela de leitura de código de barras / QR Code usando a câmera.
///
/// Compatível com `mobile_scanner: ^3.5.5` — a inicialização da câmera é
/// feita manualmente via `controller.start()` dentro de um try/catch,
/// em vez de depender de callbacks de erro do widget (que variam entre
/// versões do pacote). Qualquer falha nativa é capturada e exibida numa
/// tela amigável, sem derrubar o app.
///
/// - Se [continuousMode] for `false`, a tela fecha automaticamente
///   (`Navigator.pop`) assim que o primeiro código válido é lido.
/// - Se [continuousMode] for `true`, a câmera permanece aberta e cada
///   código lido é enviado via [onDetected]; o usuário fecha manualmente
///   pelo X ou pelo botão "Concluir".
/// - [soundEnabled] controla o feedback sonoro/tátil a cada leitura.
class BarcodeScannerScreen extends StatefulWidget {
  final bool continuousMode;
  final bool soundEnabled;
  final ValueChanged<String> onDetected;

  const BarcodeScannerScreen({
    super.key,
    required this.onDetected,
    this.continuousMode = false,
    this.soundEnabled = true,
  });

  @override
  State<BarcodeScannerScreen> createState() => _BarcodeScannerScreenState();
}

/// Estados possíveis da tela, cobrindo permissão, inicialização e erro
/// de câmera de forma explícita — nunca deixando o usuário numa tela
/// preta sem explicação.
enum _ScanStatus {
  checkingPermission,
  permissionDenied,
  permissionPermanentlyDenied,
  starting,
  running,
  error,
}

class _BarcodeScannerScreenState extends State<BarcodeScannerScreen>
    with WidgetsBindingObserver {
  MobileScannerController? _controller;

  _ScanStatus _status = _ScanStatus.checkingPermission;
  String? _errorMessage;
  bool _pausedForLifecycle = false;
  bool _torchOn = false;

  String? _lastCode;
  DateTime? _lastDetectionTime;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _checkPermissionAndStart();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _disposeController();
    super.dispose();
  }

  void _disposeController() {
    try {
      _controller?.dispose();
    } catch (_) {
      // Ignora erros ao descartar um controller que já pode estar em
      // estado inválido — nunca deve travar o fechamento da tela.
    }
    _controller = null;
  }

  // ---------------------------------------------------------------------
  // Ciclo de vida do app: pausa a câmera quando o app vai para segundo
  // plano e retoma ao voltar, evitando o crash clássico de câmera presa
  // que ocorre em alguns aparelhos Android quando o app é minimizado.
  // ---------------------------------------------------------------------
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    switch (state) {
      case AppLifecycleState.inactive:
      case AppLifecycleState.paused:
        if (_status == _ScanStatus.running) {
          _pausedForLifecycle = true;
          _safeStop();
        }
        break;
      case AppLifecycleState.resumed:
        if (_pausedForLifecycle) {
          _pausedForLifecycle = false;
          _checkPermissionAndStart();
        } else if (_status == _ScanStatus.permissionDenied ||
            _status == _ScanStatus.permissionPermanentlyDenied) {
          // Usuário pode ter voltado das Configurações do sistema após
          // conceder a permissão manualmente.
          _checkPermissionAndStart();
        }
        break;
      default:
        break;
    }
  }

  Future<void> _safeStop() async {
    try {
      await _controller?.stop();
    } catch (_) {
      // Falha ao pausar não é crítica; a tela será reconstruída ao
      // reiniciar a câmera de qualquer forma.
    }
  }

  // ---------------------------------------------------------------------
  // Permissão
  // ---------------------------------------------------------------------
  Future<void> _checkPermissionAndStart() async {
    setState(() => _status = _ScanStatus.checkingPermission);

    try {
      var status = await Permission.camera.status;

      if (status.isDenied) {
        status = await Permission.camera.request();
      }

      if (status.isGranted) {
        await _startCamera();
        return;
      }

      setState(() {
        _status = (status.isPermanentlyDenied || status.isRestricted)
            ? _ScanStatus.permissionPermanentlyDenied
            : _ScanStatus.permissionDenied;
      });
    } catch (e) {
      // Mesmo uma falha ao checar permissão não deve travar o app.
      setState(() {
        _status = _ScanStatus.error;
        _errorMessage = 'Erro ao verificar permissão de câmera.\nDetalhe: $e';
      });
    }
  }

  // ---------------------------------------------------------------------
  // Inicialização da câmera — try/catch amigável, sem derrubar o app.
  // ---------------------------------------------------------------------
  Future<void> _startCamera() async {
    setState(() => _status = _ScanStatus.starting);

    // Descarta qualquer controller anterior antes de criar um novo,
    // evitando conflitos de "câmera já em uso" em tentativas repetidas.
    _disposeController();

    final controller = MobileScannerController(
      detectionSpeed: DetectionSpeed.normal,
      facing: CameraFacing.back,
      torchEnabled: false,
    );

    try {
      await controller.start();
      if (!mounted) {
        controller.dispose();
        return;
      }
      setState(() {
        _controller = controller;
        _status = _ScanStatus.running;
        _torchOn = false;
      });
    } on MobileScannerException catch (e) {
      await _handleStartFailure(controller, _describeMobileScannerException(e));
    } on PlatformException catch (e) {
      await _handleStartFailure(
        controller,
        'Falha nativa da plataforma.\nCódigo: ${e.code}\nDetalhe: ${e.message ?? '-'}',
      );
    } catch (e) {
      await _handleStartFailure(controller, 'Erro inesperado ao abrir a câmera.\nDetalhe: $e');
    }
  }

  Future<void> _handleStartFailure(MobileScannerController controller, String message) async {
    debugPrint('[BarcodeScanner] Falha ao iniciar câmera: $message');
    try {
      controller.dispose();
    } catch (_) {
      // Ignora erro ao descartar controller que falhou ao iniciar.
    }
    if (!mounted) return;
    setState(() {
      _status = _ScanStatus.error;
      _errorMessage = message;
    });
  }

  String _describeMobileScannerException(MobileScannerException e) {
    final detail = e.errorDetails?.message;
    final base = 'Código: ${e.errorCode}';
    if (detail != null && detail.isNotEmpty) {
      return '$base\nDetalhe: $detail';
    }
    switch (e.errorCode) {
      case MobileScannerErrorCode.permissionDenied:
        return '$base\nPermissão de câmera negada pelo sistema.';
      case MobileScannerErrorCode.unsupported:
        return '$base\nEste dispositivo não tem suporte a leitura de câmera.';
      default:
        return '$base\nSe estiver em um celular físico, tente atualizar o '
            'Google Play Services e feche outros apps que usem a câmera.';
    }
  }

  // ---------------------------------------------------------------------
  // Detecção de código
  // ---------------------------------------------------------------------
  void _handleDetection(BarcodeCapture capture) {
    // Protegido por try/catch: uma leitura malformada nunca deve travar
    // a tela ou o app.
    try {
      final barcodes = capture.barcodes;
      if (barcodes.isEmpty) return;

      final rawValue = barcodes.first.rawValue;
      if (rawValue == null || rawValue.isEmpty) return;

      final now = DateTime.now();
      if (_lastCode == rawValue &&
          _lastDetectionTime != null &&
          now.difference(_lastDetectionTime!) < const Duration(seconds: 2)) {
        return;
      }
      _lastCode = rawValue;
      _lastDetectionTime = now;

      _giveFeedback();
      widget.onDetected(rawValue);

      if (widget.continuousMode) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            duration: const Duration(milliseconds: 900),
            backgroundColor: AppColors.primaryGreen,
            content: Text('Código lido: $rawValue'),
          ),
        );
      } else {
        Navigator.of(context).pop();
      }
    } catch (e) {
      debugPrint('[BarcodeScanner] Erro ao processar leitura: $e');
    }
  }

  void _giveFeedback() {
    try {
      HapticFeedback.mediumImpact();
      if (widget.soundEnabled) {
        SystemSound.play(SystemSoundType.click);
      }
    } catch (_) {
      // Feedback tátil/sonoro é cosmético — nunca deve interromper o fluxo.
    }
  }

  Future<void> _toggleTorch() async {
    try {
      await _controller?.toggleTorch();
      setState(() => _torchOn = !_torchOn);
    } catch (e) {
      debugPrint('[BarcodeScanner] Erro ao alternar lanterna: $e');
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Não foi possível controlar a lanterna neste aparelho.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: switch (_status) {
        _ScanStatus.checkingPermission => const _CenteredMessage(
            showSpinner: true,
            title: 'Verificando permissão da câmera...',
          ),
        _ScanStatus.starting => const _CenteredMessage(
            showSpinner: true,
            title: 'Abrindo a câmera...',
          ),
        _ScanStatus.permissionDenied => _PermissionRequestView(
            onRetry: _checkPermissionAndStart,
            onCancel: () => Navigator.of(context).pop(),
          ),
        _ScanStatus.permissionPermanentlyDenied => _PermissionSettingsView(
            onOpenSettings: openAppSettings,
            onRetry: _checkPermissionAndStart,
          ),
        _ScanStatus.error => _ScannerErrorView(
            message: _errorMessage ?? 'Erro desconhecido ao abrir a câmera.',
            onRetry: _startCamera,
            onCancel: () => Navigator.of(context).pop(),
          ),
        _ScanStatus.running => _buildScannerView(context),
      },
    );
  }

  Widget _buildScannerView(BuildContext context) {
    final controller = _controller;
    if (controller == null) {
      // Estado defensivo: nunca deveria acontecer (status running implica
      // controller != null), mas evita crash caso ocorra.
      return const _CenteredMessage(showSpinner: true, title: 'Preparando câmera...');
    }

    return Stack(
      fit: StackFit.expand,
      children: [
        MobileScanner(
          controller: controller,
          onDetect: _handleDetection,
        ),
        _buildScanOverlay(),
        _buildTopBar(context),
        if (widget.continuousMode) _buildContinuousFooter(),
      ],
    );
  }

  Widget _buildTopBar(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            IconButton(
              onPressed: () => Navigator.of(context).pop(),
              icon: const Icon(Icons.close, color: Colors.white, size: 28),
            ),
            Text(
              widget.continuousMode ? 'Escaneamento contínuo' : 'Aponte para o código',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
            ),
            IconButton(
              onPressed: _toggleTorch,
              icon: Icon(
                _torchOn ? Icons.flash_on : Icons.flash_off,
                color: Colors.white,
                size: 26,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildScanOverlay() {
    return Center(
      child: Container(
        width: 260,
        height: 180,
        decoration: BoxDecoration(
          border: Border.all(color: AppColors.primaryGreen, width: 3),
          borderRadius: BorderRadius.circular(16),
        ),
      ),
    );
  }

  Widget _buildContinuousFooter() {
    return Positioned(
      left: 16,
      right: 16,
      bottom: 24,
      child: SafeArea(
        top: false,
        child: ElevatedButton.icon(
          onPressed: () => Navigator.of(context).pop(),
          icon: const Icon(Icons.check),
          label: const Text('CONCLUIR ESCANEAMENTO'),
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primaryGreen,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------
// Widgets de estado (permissão, carregando, erro)
// ---------------------------------------------------------------------

class _CenteredMessage extends StatelessWidget {
  final String title;
  final bool showSpinner;

  const _CenteredMessage({required this.title, this.showSpinner = false});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (showSpinner) const CircularProgressIndicator(color: AppColors.primaryGreen),
            const SizedBox(height: 16),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white, fontSize: 15),
            ),
          ],
        ),
      ),
    );
  }
}

class _PermissionRequestView extends StatelessWidget {
  final VoidCallback onRetry;
  final VoidCallback onCancel;

  const _PermissionRequestView({required this.onRetry, required this.onCancel});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.camera_alt_outlined, size: 56, color: Colors.white70),
            const SizedBox(height: 16),
            const Text(
              'Precisamos da sua permissão para usar a câmera e ler o código de barras.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white, fontSize: 15),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: onRetry,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryBlue,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text('Permitir acesso à câmera'),
            ),
            const SizedBox(height: 12),
            TextButton(
              onPressed: onCancel,
              child: const Text('Cancelar', style: TextStyle(color: Colors.white70)),
            ),
          ],
        ),
      ),
    );
  }
}

class _PermissionSettingsView extends StatelessWidget {
  final VoidCallback onOpenSettings;
  final VoidCallback onRetry;

  const _PermissionSettingsView({required this.onOpenSettings, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.no_photography_outlined, size: 56, color: Colors.white70),
            const SizedBox(height: 16),
            const Text(
              'O acesso à câmera foi bloqueado permanentemente para este app.\n'
              'Ative manualmente em Configurações > Apps > Inventário > Permissões.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white, fontSize: 15),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: onOpenSettings,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryBlue,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text('Abrir Configurações'),
            ),
            const SizedBox(height: 12),
            TextButton(
              onPressed: onRetry,
              child: const Text('Já ativei, tentar novamente', style: TextStyle(color: Colors.white70)),
            ),
          ],
        ),
      ),
    );
  }
}

/// Tela de erro amigável para falhas de câmera (hardware ocupado,
/// indisponível, erro nativo genérico, etc.) — nunca deixa o app travar.
class _ScannerErrorView extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  final VoidCallback onCancel;

  const _ScannerErrorView({
    required this.message,
    required this.onRetry,
    required this.onCancel,
  });

  @override
  Widget build(BuildContext context) {
    debugPrint('[BarcodeScanner] Exibindo tela de erro: $message');

    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 56, color: Colors.orangeAccent),
            const SizedBox(height: 16),
            const Text(
              'Não foi possível abrir a câmera.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white70, fontSize: 13),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: onRetry,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryBlue,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text('Tentar novamente'),
            ),
            const SizedBox(height: 12),
            TextButton(
              onPressed: onCancel,
              child: const Text('Fechar', style: TextStyle(color: Colors.white70)),
            ),
          ],
        ),
      ),
    );
  }
}
