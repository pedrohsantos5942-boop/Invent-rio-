import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../providers/inventory_provider.dart';
import '../theme/app_colors.dart';

/// Tela de Configurações: preferências de escaneamento, exportação de
/// dados (CSV/JSON) e limpeza do inventário atual.
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _exportData(BuildContext context, {required bool asJson}) async {
    final provider = context.read<InventoryProvider>();

    if (provider.totalRecords == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Não há itens para exportar.')),
      );
      return;
    }

    final content = asJson ? provider.exportAsJson() : provider.exportAsCsv();
    final extension = asJson ? 'json' : 'csv';
    final fileName =
        'inventario_${DateTime.now().millisecondsSinceEpoch}.$extension';

    try {
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/$fileName');
      await file.writeAsString(content);

      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Exportação do inventário (${provider.totalRecords} itens)',
      );
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao exportar: $e')),
        );
      }
    }
  }

  Future<void> _confirmClearAll(BuildContext context) async {
    final provider = context.read<InventoryProvider>();

    if (provider.totalRecords == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('O inventário já está vazio.')),
      );
      return;
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Limpar inventário atual'),
        content: Text(
          'Esta ação apagará permanentemente os ${provider.totalRecords} '
          'itens registrados na memória. Deseja continuar?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Limpar tudo', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirmed == true && context.mounted) {
      context.read<InventoryProvider>().clearAll();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Inventário limpo com sucesso.')),
      );
    }
  }

  void _showExportSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.cardBackground,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 8),
                child: Text(
                  'Exportar dados do inventário',
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                ),
              ),
              ListTile(
                leading: const Icon(Icons.table_chart_outlined, color: AppColors.primaryBlue),
                title: const Text('Exportar como CSV'),
                onTap: () {
                  Navigator.pop(ctx);
                  _exportData(context, asJson: false);
                },
              ),
              ListTile(
                leading: const Icon(Icons.data_object, color: AppColors.primaryBlue),
                title: const Text('Exportar como JSON'),
                onTap: () {
                  Navigator.pop(ctx);
                  _exportData(context, asJson: true);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          _buildHeader(context),
          Expanded(
            child: Consumer<InventoryProvider>(
              builder: (context, provider, _) {
                return ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    _SectionLabel('Escaneamento'),
                    _SettingsCard(
                      children: [
                        _SwitchTile(
                          icon: Icons.qr_code_scanner,
                          title: 'Modo de escaneamento contínuo',
                          subtitle:
                              'Mantém a câmera aberta para ler vários códigos seguidos',
                          value: provider.continuousScanMode,
                          onChanged: provider.setContinuousScanMode,
                        ),
                        const Divider(height: 1, indent: 56),
                        _SwitchTile(
                          icon: Icons.volume_up_outlined,
                          title: 'Som ao escanear',
                          subtitle: 'Emite um bipe de confirmação a cada leitura',
                          value: provider.soundOnScan,
                          onChanged: provider.setSoundOnScan,
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    _SectionLabel('Dados'),
                    _SettingsCard(
                      children: [
                        _ActionTile(
                          icon: Icons.ios_share,
                          iconColor: AppColors.primaryBlue,
                          title: 'Exportar dados',
                          subtitle: '${provider.totalRecords} itens no inventário atual',
                          onTap: () => _showExportSheet(context),
                        ),
                        const Divider(height: 1, indent: 56),
                        _ActionTile(
                          icon: Icons.delete_outline,
                          iconColor: Colors.red,
                          title: 'Limpar inventário atual',
                          subtitle: 'Apaga todos os registros salvos da memória',
                          titleColor: Colors.red,
                          onTap: () => _confirmClearAll(context),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    _SectionLabel('Inventariantes'),
                    _SettingsCard(
                      children: [
                        _ManageOperatorsTile(provider: provider),
                      ],
                    ),
                    const SizedBox(height: 24),
                    _SectionLabel('Sobre'),
                    _SettingsCard(
                      children: const [
                        _InfoTile(title: 'Versão do app', value: '1.0.0'),
                        Divider(height: 1, indent: 56),
                        _InfoTile(title: 'Inventariante Ativo', value: 'Pedro Henrique'),
                      ],
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 12,
        bottom: 16,
        left: 16,
        right: 16,
      ),
      decoration: const BoxDecoration(
        color: AppColors.primaryBlue,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(18)),
      ),
      child: const Text(
        'Configurações',
        style: TextStyle(
          color: Colors.white,
          fontSize: 18,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 8),
      child: Text(
        text.toUpperCase(),
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w700,
          color: AppColors.textHint,
          letterSpacing: 0.6,
        ),
      ),
    );
  }
}

class _SettingsCard extends StatelessWidget {
  final List<Widget> children;
  const _SettingsCard({required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(14),
        boxShadow: AppColors.softShadow,
      ),
      child: Column(children: children),
    );
  }
}

class _SwitchTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  const _SwitchTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return SwitchListTile(
      value: value,
      onChanged: onChanged,
      activeColor: AppColors.primaryGreen,
      secondary: Icon(icon, color: AppColors.primaryBlue),
      title: Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
      subtitle: Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
    );
  }
}

class _ActionTile extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String subtitle;
  final Color? titleColor;
  final VoidCallback onTap;

  const _ActionTile({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.titleColor,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      leading: Icon(icon, color: iconColor),
      title: Text(
        title,
        style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: titleColor),
      ),
      subtitle: Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
      trailing: const Icon(Icons.chevron_right, color: AppColors.textHint),
    );
  }
}

class _InfoTile extends StatelessWidget {
  final String title;
  final String value;
  const _InfoTile({required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: const Icon(Icons.info_outline, color: AppColors.textHint),
      title: Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
      trailing: Text(value, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
    );
  }
}

class _ManageOperatorsTile extends StatelessWidget {
  final InventoryProvider provider;

  const _ManageOperatorsTile({required this.provider});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ListTile(
          leading: const Icon(Icons.person_add, color: AppColors.primaryOrange),
          title: const Text(
            'Gerenciar Inventariantes',
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
          ),
          subtitle: Text(
            '${provider.operators.length} operadores registrados',
            style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
          ),
          trailing: const Icon(Icons.chevron_right, color: AppColors.textHint),
          onTap: () => _showManageOperatorsDialog(context),
        ),
      ],
    );
  }

  void _showManageOperatorsDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.cardBackground,
        title: const Text('Gerenciar Inventariantes', style: TextStyle(color: AppColors.textPrimary)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Lista de operadores
              SizedBox(
                height: 300,
                width: double.maxFinite,
                child: ListView.builder(
                  itemCount: provider.operators.length,
                  itemBuilder: (context, index) {
                    final op = provider.operators[index];
                    return ListTile(
                      title: Text(op.name, style: const TextStyle(color: AppColors.textPrimary)),
                      subtitle: Text(op.role, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                      trailing: provider.operators.length > 1
                          ? IconButton(
                              icon: const Icon(Icons.delete_outline, color: Colors.red, size: 20),
                              onPressed: () {
                                provider.removeOperator(op.id);
                                Navigator.pop(ctx);
                                _showManageOperatorsDialog(context);
                              },
                            )
                          : null,
                    );
                  },
                ),
              ),
              const Divider(color: AppColors.border, height: 16),
              // Botão para adicionar novo operador
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.pop(ctx);
                  _showAddOperatorDialog(context);
                },
                icon: const Icon(Icons.add),
                label: const Text('Adicionar Operador'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryOrange,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Fechar', style: TextStyle(color: AppColors.primaryOrange)),
          ),
        ],
      ),
    );
  }

  void _showAddOperatorDialog(BuildContext context) {
    final nameController = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.cardBackground,
        title: const Text('Novo Inventariante', style: TextStyle(color: AppColors.textPrimary)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              style: const TextStyle(color: AppColors.textPrimary),
              decoration: InputDecoration(
                hintText: 'Nome do operador',
                hintStyle: const TextStyle(color: AppColors.textHint),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: AppColors.border),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: AppColors.border),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: AppColors.primaryOrange),
                ),
              ),
              autofocus: true,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancelar', style: TextStyle(color: AppColors.textSecondary)),
          ),
          TextButton(
            onPressed: () {
              final name = nameController.text.trim();
              if (name.isNotEmpty) {
                provider.addOperator(name);
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    backgroundColor: AppColors.successGreen,
                    content: Text('Operador "$name" adicionado com sucesso!'),
                  ),
                );
              }
            },
            child: const Text('Adicionar', style: TextStyle(color: AppColors.primaryOrange)),
          ),
        ],
      ),
    );
  }
}
