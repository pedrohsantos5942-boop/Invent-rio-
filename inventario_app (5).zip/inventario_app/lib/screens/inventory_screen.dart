import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/inventory_item.dart';
import '../providers/inventory_provider.dart';
import '../providers/navigation_provider.dart';
import '../theme/app_colors.dart';
import '../widgets/stepper_field.dart';
import 'barcode_scanner_screen.dart';
import 'calculator_screen.dart';

/// Tela principal de Inventário — reformulada:
/// - Tema Preto (#1E1E1E) e Laranja (#FF6B00)
/// - Drawer com menu lateral (trocar operador, depósito, etc.)
/// - Sem campos de Lote, Validade e Registro de Lote
/// - Quantidade editável por digitação + botões +/-
/// - Ícone nuvem desativado/pendente
class InventoryScreen extends StatefulWidget {
  const InventoryScreen({super.key});

  @override
  State<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends State<InventoryScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final TextEditingController _barcodeController = TextEditingController();
  final TextEditingController _locationController = TextEditingController();
  final TextEditingController _quantityController = TextEditingController(text: '1');
  final TextEditingController _filterController = TextEditingController();

  int _quantity = 1;

  @override
  void dispose() {
    _barcodeController.dispose();
    _locationController.dispose();
    _quantityController.dispose();
    _filterController.dispose();
    super.dispose();
  }

  // =========================================================================
  // Ações
  // =========================================================================

  Future<void> _openScanner() async {
    final provider = context.read<InventoryProvider>();
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => BarcodeScannerScreen(
          continuousMode: provider.continuousScanMode,
          soundEnabled: provider.soundOnScan,
          onDetected: (code) {
            setState(() => _barcodeController.text = code);
          },
        ),
      ),
    );
  }

  Future<void> _openCalculator() async {
    final result = await Navigator.push<int>(
      context,
      MaterialPageRoute(builder: (_) => const CalculatorScreen()),
    );
    if (result != null) {
      setState(() {
        _quantity = result;
        _quantityController.text = result.toString();
      });
    }
  }

  void _updateQuantityFromTextField() {
    final text = _quantityController.text.trim();
    if (text.isEmpty) {
      _quantity = 0;
    } else {
      final parsed = int.tryParse(text);
      if (parsed != null && parsed >= 0) {
        _quantity = parsed;
      } else {
        _quantityController.text = _quantity.toString();
      }
    }
    setState(() {});
  }

  void _confirmPosition() {
    if (_locationController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Informe a posição antes de confirmar.')),
      );
      return;
    }
    FocusScope.of(context).unfocus();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: AppColors.successGreen,
        content: Text('Posição "${_locationController.text.trim()}" confirmada.'),
      ),
    );
  }

  void _addItem() {
    if (_barcodeController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Escaneie ou informe um código antes de adicionar.')),
      );
      return;
    }

    final newItem = InventoryItem(
      barcode: _barcodeController.text.trim(),
      quantity: _quantity,
      location: _locationController.text.trim().isEmpty ? '-' : _locationController.text.trim(),
      addedAt: DateTime.now(),
    );

    context.read<InventoryProvider>().addItem(newItem);

    setState(() {
      _barcodeController.clear();
      _locationController.clear();
      _quantityController.text = '1';
      _quantity = 1;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        backgroundColor: AppColors.successGreen,
        content: Text('Item adicionado com sucesso!'),
      ),
    );
  }

  void _showCloudPendingMessage() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Integração com armazém será disponibilizada em breve.'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: AppColors.background,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _buildUserCard(),
                  const SizedBox(height: 16),
                  _buildScanButton(),
                  const SizedBox(height: 20),
                  _buildBarcodeField(),
                  const SizedBox(height: 14),
                  _buildLocationRow(),
                  const SizedBox(height: 14),
                  _buildQuantitySection(),
                  const SizedBox(height: 20),
                  _buildAddButton(),
                  const SizedBox(height: 28),
                  _buildRecentHeader(),
                  const SizedBox(height: 12),
                  _buildFilterField(),
                  const SizedBox(height: 12),
                  _buildRecentList(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // =========================================================================
  // Header / AppBar
  // =========================================================================

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: AppColors.darkBackground,
      elevation: 0,
      leading: IconButton(
        onPressed: () => _scaffoldKey.currentState?.openDrawer(),
        icon: const Icon(Icons.menu, color: AppColors.textPrimary, size: 28),
      ),
      title: const Text(
        'Gestão de Inventário',
        style: TextStyle(
          color: AppColors.textPrimary,
          fontSize: 18,
          fontWeight: FontWeight.w700,
        ),
      ),
      centerTitle: true,
      actions: [
        IconButton(
          onPressed: _showCloudPendingMessage,
          icon: const Icon(Icons.cloud_off, color: AppColors.pendingGrey, size: 26),
          tooltip: 'Integração em breve',
        ),
      ],
    );
  }

  // =========================================================================
  // Drawer (Menu Lateral)
  // =========================================================================

  Widget _buildDrawer() {
    return Consumer<InventoryProvider>(
      builder: (context, provider, _) {
        return Drawer(
          backgroundColor: AppColors.darkCard,
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              // Header
              UserAccountsDrawerHeader(
                accountName: Text(
                  provider.currentOperator.name,
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                accountEmail: Text(
                  'Operador de Estoque',
                  style: const TextStyle(color: AppColors.textSecondary, fontSize: 13),
                ),
                currentAccountPicture: CircleAvatar(
                  backgroundColor: AppColors.primaryOrange,
                  child: Text(
                    provider.currentOperator.name.substring(0, 1).toUpperCase(),
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                ),
                decoration: BoxDecoration(
                  color: AppColors.primaryOrange.withOpacity(0.8),
                ),
              ),
              const SizedBox(height: 8),

              // Trocar Depósito
              ListTile(
                leading: const Icon(Icons.warehouse, color: AppColors.primaryOrange),
                title: const Text('Trocar Depósito', style: TextStyle(color: AppColors.textPrimary)),
                onTap: () {
                  Navigator.pop(context);
                  _showChangeWarehouseDialog(provider);
                },
              ),

              // Importar Base (CSV)
              ListTile(
                leading: const Icon(Icons.upload_file, color: AppColors.primaryOrange),
                title: const Text('Importar Base (CSV)', style: TextStyle(color: AppColors.textPrimary)),
                onTap: () {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Funcionalidade em desenvolvimento.')),
                  );
                },
              ),

              // Exportar Contagem
              ListTile(
                leading: const Icon(Icons.download, color: AppColors.primaryOrange),
                title: const Text('Exportar Contagem', style: TextStyle(color: AppColors.textPrimary)),
                onTap: () {
                  Navigator.pop(context);
                  context.read<InventoryProvider>().exportAsJson();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Contagem exportada.')),
                  );
                },
              ),

              const Divider(color: AppColors.border, height: 16),

              // Modo Bipador Contínuo
              ListTile(
                leading: const Icon(Icons.volume_up, color: AppColors.primaryOrange),
                title: const Text('Modo Bipador Contínuo', style: TextStyle(color: AppColors.textPrimary)),
                trailing: Consumer<InventoryProvider>(
                  builder: (context, provider, _) => Switch(
                    value: provider.continuousScanMode,
                    onChanged: provider.setContinuousScanMode,
                    activeColor: AppColors.primaryOrange,
                  ),
                ),
              ),

              const Divider(color: AppColors.border, height: 16),

              // Sair
              ListTile(
                leading: const Icon(Icons.logout, color: Colors.red),
                title: const Text('Sair', style: TextStyle(color: Colors.red)),
                onTap: () {
                  Navigator.pop(context);
                  showDialog(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      backgroundColor: AppColors.cardBackground,
                      title: const Text('Sair do app?', style: TextStyle(color: AppColors.textPrimary)),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(ctx),
                          child: const Text('Cancelar', style: TextStyle(color: AppColors.primaryOrange)),
                        ),
                        TextButton(
                          onPressed: () => Navigator.pop(ctx) /* TODO: implementar logout */,
                          child: const Text('Sair', style: TextStyle(color: Colors.red)),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void _showChangeWarehouseDialog(InventoryProvider provider) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.cardBackground,
        title: const Text('Selecionar Depósito', style: TextStyle(color: AppColors.textPrimary)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _warehouseOption(ctx, provider, 'Depósito Principal'),
            _warehouseOption(ctx, provider, 'Depósito Secundário'),
            _warehouseOption(ctx, provider, 'Almoxarifado'),
          ],
        ),
      ),
    );
  }

  Widget _warehouseOption(BuildContext ctx, InventoryProvider provider, String name) {
    return ListTile(
      title: Text(name, style: const TextStyle(color: AppColors.textPrimary)),
      selected: provider.currentWarehouse == name,
      selectedTileColor: AppColors.primaryOrange.withOpacity(0.2),
      onTap: () {
        provider.setCurrentWarehouse(name);
        Navigator.pop(ctx);
      },
    );
  }

  // =========================================================================
  // Seções da Tela
  // =========================================================================

  Widget _buildUserCard() {
    return Consumer<InventoryProvider>(
      builder: (context, provider, _) {
        return Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppColors.cardBackground,
            borderRadius: BorderRadius.circular(14),
            boxShadow: AppColors.softShadow,
          ),
          child: Row(
            children: [
              CircleAvatar(
                radius: 22,
                backgroundColor: AppColors.primaryOrange,
                child: Text(
                  provider.currentOperator.name.substring(0, 1).toUpperCase(),
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Inventariante',
                      style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      provider.currentOperator.name,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                  ],
                ),
              ),
              TextButton(
                onPressed: () => _showChangeOperatorDialog(provider),
                child: const Text(
                  'Alterar',
                  style: TextStyle(
                    color: AppColors.primaryOrange,
                    fontWeight: FontWeight.w700,
                    fontSize: 14,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showChangeOperatorDialog(InventoryProvider provider) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.cardBackground,
        title: const Text('Selecionar Inventariante', style: TextStyle(color: AppColors.textPrimary)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: provider.operators
              .map((op) => ListTile(
                    title: Text(op.name, style: const TextStyle(color: AppColors.textPrimary)),
                    selected: provider.currentOperatorId == op.id,
                    selectedTileColor: AppColors.primaryOrange.withOpacity(0.2),
                    onTap: () {
                      provider.setCurrentOperator(op.id);
                      Navigator.pop(ctx);
                    },
                  ))
              .toList(),
        ),
      ),
    );
  }

  Widget _buildScanButton() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        boxShadow: AppColors.buttonShadow(AppColors.primaryOrange),
      ),
      child: ElevatedButton.icon(
        onPressed: _openScanner,
        icon: const Icon(Icons.qr_code_scanner, size: 22),
        label: const Text('ESCANEAR CÓDIGO DE BARRAS'),
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primaryOrange,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 18),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          elevation: 0,
          textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 0.3),
        ),
      ),
    );
  }

  Widget _buildBarcodeField() {
    return _LabeledInput(
      label: 'Código escaneado',
      controller: _barcodeController,
      hint: 'Aguardando leitura...',
      icon: Icons.copy_outlined,
      onIconTap: () {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Código copiado.')),
        );
      },
    );
  }

  Widget _buildLocationRow() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Posição / Localização',
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: AppColors.textSecondary,
          ),
        ),
        const SizedBox(height: 6),
        Row(
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: AppColors.cardBackground,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppColors.border),
                ),
                child: TextField(
                  controller: _locationController,
                  style: const TextStyle(color: AppColors.textPrimary),
                  decoration: InputDecoration(
                    hintText: 'Ex: A-12-03',
                    hintStyle: const TextStyle(color: AppColors.textHint, fontSize: 14),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                    suffixIcon: const Icon(Icons.location_on_outlined,
                        color: AppColors.primaryOrange, size: 20),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                boxShadow: AppColors.buttonShadow(AppColors.primaryOrange),
              ),
              child: ElevatedButton(
                onPressed: _confirmPosition,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryOrange,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  elevation: 0,
                ),
                child: const Text(
                  'Confirmar',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildQuantitySection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Quantidade',
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: AppColors.textSecondary,
          ),
        ),
        const SizedBox(height: 6),
        Row(
          children: [
            // Botão -
            GestureDetector(
              onTap: () => setState(() {
                if (_quantity > 0) _quantity--;
                _quantityController.text = _quantity.toString();
              }),
              child: Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: AppColors.lightGrey,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.remove, color: AppColors.textPrimary, size: 20),
              ),
            ),
            const SizedBox(width: 8),

            // Campo editável
            Expanded(
              child: GestureDetector(
                onTap: () {
                  _quantityController.selection = TextSelection(
                    baseOffset: 0,
                    extentOffset: _quantityController.text.length,
                  );
                  FocusScope.of(context).requestFocus(FocusNode());
                  showDialog(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      backgroundColor: AppColors.cardBackground,
                      title: const Text('Inserir Quantidade', style: TextStyle(color: AppColors.textPrimary)),
                      content: TextField(
                        controller: _quantityController,
                        keyboardType: TextInputType.number,
                        style: const TextStyle(color: AppColors.textPrimary),
                        decoration: InputDecoration(
                          hintText: 'Quantidade',
                          hintStyle: const TextStyle(color: AppColors.textHint),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: const BorderSide(color: AppColors.border),
                          ),
                        ),
                        autofocus: true,
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(ctx),
                          child: const Text('Cancelar', style: TextStyle(color: AppColors.textSecondary)),
                        ),
                        TextButton(
                          onPressed: () {
                            _updateQuantityFromTextField();
                            Navigator.pop(ctx);
                          },
                          child: const Text('OK', style: TextStyle(color: AppColors.primaryOrange)),
                        ),
                      ],
                    ),
                  );
                },
                child: Container(
                  height: 48,
                  decoration: BoxDecoration(
                    color: AppColors.cardBackground,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppColors.border),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    '$_quantity',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),

            // Botão +
            GestureDetector(
              onTap: () => setState(() {
                _quantity++;
                _quantityController.text = _quantity.toString();
              }),
              child: Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: AppColors.lightGrey,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.add, color: AppColors.textPrimary, size: 20),
              ),
            ),
            const SizedBox(width: 8),

            // Botão Calculadora
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                boxShadow: AppColors.buttonShadow(AppColors.primaryOrange),
              ),
              child: ElevatedButton.icon(
                onPressed: _openCalculator,
                icon: const Icon(Icons.calculate_outlined, size: 18),
                label: const Text('Calc'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryOrange,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  elevation: 0,
                  textStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildAddButton() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        boxShadow: AppColors.buttonShadow(AppColors.successGreen),
      ),
      child: ElevatedButton.icon(
        onPressed: _addItem,
        icon: const Icon(Icons.check_circle_outline, size: 22),
        label: const Text('ADICIONAR ITEM'),
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.successGreen,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 18),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          elevation: 0,
          textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 0.3),
        ),
      ),
    );
  }

  Widget _buildRecentHeader() {
    return Row(
      children: [
        const Expanded(
          child: Text(
            'Últimos itens adicionados',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
        ),
        TextButton(
          onPressed: () => context.read<NavigationProvider>().setIndex(1),
          child: const Text(
            'Ver todos',
            style: TextStyle(
              color: AppColors.primaryOrange,
              fontWeight: FontWeight.w600,
              fontSize: 13,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildFilterField() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.border),
      ),
      child: TextField(
        controller: _filterController,
        onChanged: (_) => setState(() {}),
        style: const TextStyle(color: AppColors.textPrimary),
        decoration: InputDecoration(
          hintText: 'Filtrar por localização...',
          hintStyle: const TextStyle(color: AppColors.textHint, fontSize: 13),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          prefixIcon: const Icon(Icons.search, color: AppColors.textHint, size: 20),
        ),
      ),
    );
  }

  Widget _buildRecentList() {
    return Consumer<InventoryProvider>(
      builder: (context, provider, _) {
        final query = _filterController.text.trim().toLowerCase();
        var items = provider.recentItems;
        if (query.isNotEmpty) {
          items = items
              .where((e) =>
                  e.barcode.toLowerCase().contains(query) ||
                  e.location.toLowerCase().contains(query))
              .toList();
        }

        if (items.isEmpty) {
          return const Padding(
            padding: EdgeInsets.symmetric(vertical: 24),
            child: Center(
              child: Text(
                'Nenhum item adicionado ainda.',
                style: TextStyle(color: AppColors.textSecondary),
              ),
            ),
          );
        }

        return ListView.separated(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: items.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (context, index) => _RecentItemTile(item: items[index]),
        );
      },
    );
  }
}

// =========================================================================
// Widgets auxiliares
// =========================================================================

class _LabeledInput extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final String hint;
  final IconData icon;
  final VoidCallback? onIconTap;

  const _LabeledInput({
    required this.label,
    required this.controller,
    required this.hint,
    required this.icon,
    this.onIconTap,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: AppColors.textSecondary,
          ),
        ),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(
            color: AppColors.cardBackground,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.border),
          ),
          child: TextField(
            controller: controller,
            style: const TextStyle(color: AppColors.textPrimary),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(color: AppColors.textHint, fontSize: 14),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
              suffixIcon: IconButton(
                icon: Icon(icon, color: AppColors.primaryOrange, size: 20),
                onPressed: onIconTap,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _RecentItemTile extends StatelessWidget {
  final InventoryItem item;

  const _RecentItemTile({required this.item});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(12),
        boxShadow: AppColors.softShadow,
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: AppColors.primaryOrange.withOpacity(0.2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.inventory_2_outlined,
                color: AppColors.primaryOrange, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.barcode,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  item.location,
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '${item.quantity} un.',
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                item.formattedTime,
                style: const TextStyle(
                  fontSize: 11,
                  color: AppColors.textHint,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
