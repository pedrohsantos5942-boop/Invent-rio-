import 'package:flutter/material.dart';

/// Paleta de cores centralizada do app — tema Preto e Laranja:
/// - Preto escuro (#1E1E1E) para headers, backgrounds escuros
/// - Laranja vibrante (#FF6B00) para botões, destaques, seleções
class AppColors {
  AppColors._();

  // Cores principais: Preto e Laranja
  static const Color primaryBlack = Color(0xFF1E1E1E);
  static const Color primaryOrange = Color(0xFFFF6B00);
  static const Color primaryOrangeDark = Color(0xFFE55A00);
  static const Color primaryOrangeLight = Color(0xFFFFE5CC);

  // Cores de feedback/status (verde mantido para sucesso, vermelho para erro)
  static const Color successGreen = Color(0xFF34A853);
  static const Color errorRed = Color(0xFFD32F2F);

  // Backgrounds
  static const Color background = Color(0xFF121212);
  static const Color cardBackground = Color(0xFF2A2A2A);
  static const Color lightGrey = Color(0xFF3A3A3A);

  // Textos
  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xFFB0B0B0);
  static const Color textHint = Color(0xFF808080);

  // Bordas e dividers
  static const Color border = Color(0xFF404040);
  
  // Offline/pending (para o ícone da nuvem)
  static const Color pendingGrey = Color(0xFF707070);

  static List<BoxShadow> softShadow = [
    BoxShadow(
      color: Colors.black.withOpacity(0.06),
      blurRadius: 12,
      offset: const Offset(0, 4),
    ),
  ];

  static List<BoxShadow> buttonShadow(Color color) => [
        BoxShadow(
          color: color.withOpacity(0.35),
          blurRadius: 10,
          offset: const Offset(0, 4),
        ),
      ];
}
