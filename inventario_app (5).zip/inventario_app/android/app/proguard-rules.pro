# Flutter wrapper
-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.**  { *; }
-keep class io.flutter.util.**  { *; }
-keep class io.flutter.view.**  { *; }
-keep class io.flutter.**  { *; }
-keep class io.flutter.plugins.**  { *; }

# mobile_scanner / Google ML Kit (evita remoção de classes usadas via reflexão)
-keep class com.google.mlkit.** { *; }
-keep class com.google.android.gms.** { *; }

# permission_handler
-keep class com.baseflow.permissionhandler.** { *; }
